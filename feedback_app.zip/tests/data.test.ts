import { describe, it, expect } from "vitest";
import {
  computeStats,
  computeTagStats,
  analyzeSentiment,
  exportFeedbacksToCSV,
  MOCK_FEEDBACKS,
  DEFAULT_TAGS,
} from "../lib/data";

describe("computeStats", () => {
  it("returns zero stats for empty array", () => {
    const stats = computeStats([]);
    expect(stats.totalResponses).toBe(0);
    expect(stats.npsScore).toBe(0);
    expect(stats.avgRating).toBe(0);
  });

  it("counts active feedbacks only", () => {
    const feedbacks = [
      { ...MOCK_FEEDBACKS[0], isArchived: false },
      { ...MOCK_FEEDBACKS[1], isArchived: true },
    ];
    const stats = computeStats(feedbacks);
    expect(stats.totalResponses).toBe(1);
  });

  it("computes sentiment counts correctly", () => {
    const stats = computeStats(MOCK_FEEDBACKS);
    const total = stats.positiveCount + stats.neutralCount + stats.negativeCount;
    expect(total).toBe(stats.totalResponses);
  });

  it("computes average rating correctly", () => {
    const stats = computeStats(MOCK_FEEDBACKS);
    expect(stats.avgRating).toBeGreaterThan(0);
    expect(stats.avgRating).toBeLessThanOrEqual(5);
  });
});

describe("analyzeSentiment", () => {
  it("detects positive sentiment", () => {
    const result = analyzeSentiment("บริการดีมาก ประทับใจมาก");
    expect(result.sentiment).toBe("positive");
    expect(result.confidence).toBeGreaterThan(0.5);
  });

  it("detects negative sentiment", () => {
    const result = analyzeSentiment("สินค้าเสียหาย แย่มาก ไม่พอใจ");
    expect(result.sentiment).toBe("negative");
    expect(result.confidence).toBeGreaterThan(0.5);
  });

  it("returns neutral for unknown text", () => {
    const result = analyzeSentiment("สินค้า");
    expect(result.sentiment).toBe("neutral");
  });

  it("returns confidence between 0 and 1", () => {
    const result = analyzeSentiment("ดีมาก ประทับใจ");
    expect(result.confidence).toBeGreaterThanOrEqual(0);
    expect(result.confidence).toBeLessThanOrEqual(1);
  });
});

describe("computeTagStats", () => {
  it("returns sorted tag stats by count", () => {
    const stats = computeTagStats(MOCK_FEEDBACKS, DEFAULT_TAGS);
    expect(stats.length).toBeGreaterThan(0);
    if (stats.length > 1) {
      expect(stats[0].count).toBeGreaterThanOrEqual(stats[1].count);
    }
  });

  it("only includes tags with count > 0", () => {
    const stats = computeTagStats(MOCK_FEEDBACKS, DEFAULT_TAGS);
    stats.forEach((s) => expect(s.count).toBeGreaterThan(0));
  });
});

describe("exportFeedbacksToCSV", () => {
  it("generates CSV with header and rows", () => {
    const csv = exportFeedbacksToCSV(MOCK_FEEDBACKS, DEFAULT_TAGS);
    expect(csv).toContain("ID,ชื่อลูกค้า");
    const lines = csv.trim().split("\n");
    expect(lines.length).toBe(MOCK_FEEDBACKS.length + 1); // header + data rows
  });

  it("handles feedbacks with no tags", () => {
    const noTagFeedbacks = [{ ...MOCK_FEEDBACKS[0], tags: [] }];
    const csv = exportFeedbacksToCSV(noTagFeedbacks, DEFAULT_TAGS);
    expect(csv).toBeTruthy();
  });
});
