// ข้อมูลการจัดส่งจาก MARBOHUB (ปิดข้อมูลส่วนตัวลูกค้า)
// แสดงเฉพาะ: เลขออเดอร์, สินค้า, วันที่, สถานะ, ระยะทาง, สาขา

export type DeliveryStatus =
  | "preparing"   // กำลังเตรียมจัดส่ง
  | "delivering"  // กำลังจัดส่ง
  | "delivered"   // จัดส่งสำเร็จ
  | "cancelled";  // ยกเลิก

export type PaymentMethod = "prepaid" | "cod"; // จ่ายแล้ว / เก็บปลายทาง

export interface DeliveryItem {
  id: string;
  orderCode: string;          // #XXXXXXXX (เลขออเดอร์)
  orderDate: string;          // ISO date string
  products: {
    name: string;
    flavor: string;
    price: number;
    qty: number;
  }[];
  subtotal: number;
  shippingFee: number;
  total: number;
  status: DeliveryStatus;
  paymentMethod: PaymentMethod;
  distanceKm?: number;
  durationMin?: number;
  branch?: string;            // สาขา
  // ข้อมูลลูกค้า: ปิดทั้งหมด (ชื่อ, เบอร์, ที่อยู่ ไม่แสดง)
}

// ข้อมูลจริงจาก MARBOHUB admin/sales (27 มี.ค. 2569)
// ข้อมูลส่วนตัวลูกค้าถูกลบออกทั้งหมด
export const DELIVERY_RECORDS: DeliveryItem[] = [
  {
    id: "d1",
    orderCode: "#Y4CNMWOI",
    orderDate: "2026-03-27T15:08:00+07:00",
    products: [
      { name: "Marbo Switch POD", flavor: "Mixberry", price: 420, qty: 1 },
      { name: "Marbo Switch POD", flavor: "Peach Strawberry", price: 420, qty: 1 },
      { name: "Marbo Switch POD", flavor: "Pinkberry", price: 420, qty: 1 },
      { name: "Marbo Switch POD", flavor: "Strawberry Watermelon", price: 420, qty: 1 },
      { name: "Marbo Switch POD", flavor: "Blackberry", price: 420, qty: 1 },
    ],
    subtotal: 2100,
    shippingFee: 50,
    total: 2150,
    status: "preparing",
    paymentMethod: "prepaid",
    branch: "ลาดพร้าว",
  },
  {
    id: "d2",
    orderCode: "#M4D5ZHMN",
    orderDate: "2026-03-27T14:01:00+07:00",
    products: [
      { name: "CKS Pulse 15000 Puffs", flavor: "Mix Berry", price: 399, qty: 1 },
    ],
    subtotal: 399,
    shippingFee: 150,
    total: 549,
    status: "delivered",
    paymentMethod: "cod",
    distanceKm: 10.7,
    durationMin: 17,
    branch: "ลาดพร้าว",
  },
  {
    id: "d3",
    orderCode: "#E4KY8VKP",
    orderDate: "2026-03-27T07:40:00+07:00",
    products: [
      { name: "Marbo Bar 9000 Puffs", flavor: "Peach", price: 420, qty: 1 },
    ],
    subtotal: 420,
    shippingFee: 150,
    total: 570,
    status: "delivered",
    paymentMethod: "cod",
    distanceKm: 10.0,
    durationMin: 15,
    branch: "ลาดพร้าว",
  },
  {
    id: "d4",
    orderCode: "#MR7ZGN94",
    orderDate: "2026-03-27T06:52:00+07:00",
    products: [
      { name: "Marbo Bar 9000 Puffs", flavor: "Double Mint", price: 420, qty: 1 },
    ],
    subtotal: 420,
    shippingFee: 160,
    total: 580,
    status: "delivered",
    paymentMethod: "cod",
    distanceKm: 11.9,
    durationMin: 17,
    branch: "ลาดพร้าว",
  },
  {
    id: "d5",
    orderCode: "#DUHZCJ6N",
    orderDate: "2026-03-27T03:28:00+07:00",
    products: [
      { name: "RELX SMASH GO", flavor: "Passion Fruit – เสาวรส", price: 400, qty: 1 },
    ],
    subtotal: 400,
    shippingFee: 130,
    total: 530,
    status: "delivered",
    paymentMethod: "prepaid",
    distanceKm: 10.3,
    durationMin: 14,
    branch: "ปิ่นเกล้า",
  },
  // ตัวอย่างออเดอร์เพิ่มเติม (ย้อนหลัง) เพื่อแสดงประวัติการส่ง
  {
    id: "d6",
    orderCode: "#BX2PQRT7",
    orderDate: "2026-03-26T20:15:00+07:00",
    products: [
      { name: "SKE Crystal", flavor: "Blueberry Ice", price: 399, qty: 2 },
    ],
    subtotal: 798,
    shippingFee: 100,
    total: 898,
    status: "delivered",
    paymentMethod: "prepaid",
    distanceKm: 8.4,
    durationMin: 12,
    branch: "สุขุมวิท",
  },
  {
    id: "d7",
    orderCode: "#KL9MNVW2",
    orderDate: "2026-03-26T18:30:00+07:00",
    products: [
      { name: "RELX Pro2 (หัวพอด)", flavor: "Lemon Tea", price: 160, qty: 3 },
    ],
    subtotal: 480,
    shippingFee: 80,
    total: 560,
    status: "delivered",
    paymentMethod: "cod",
    distanceKm: 6.2,
    durationMin: 10,
    branch: "สีลม",
  },
  {
    id: "d8",
    orderCode: "#ZQ5FHWX1",
    orderDate: "2026-03-26T14:22:00+07:00",
    products: [
      { name: "Escobar 20000PUFFS", flavor: "Watermelon Ice", price: 420, qty: 1 },
      { name: "Marbo Zero Pod", flavor: "Mango", price: 160, qty: 2 },
    ],
    subtotal: 740,
    shippingFee: 120,
    total: 860,
    status: "delivered",
    paymentMethod: "prepaid",
    distanceKm: 9.8,
    durationMin: 16,
    branch: "ลาดพร้าว",
  },
];

export const DELIVERY_STATS = {
  totalOrders: 229,        // ยอดออเดอร์ทั้งหมด (จาก admin)
  todayOrders: 4,          // ออเดอร์วันนี้
  todayRevenue: 2229,      // ยอดรวมวันนี้ (บาท)
  successRate: 98,         // อัตราส่งสำเร็จ (%)
  avgDeliveryMin: 15,      // เวลาส่งเฉลี่ย (นาที)
};

export function getStatusLabel(status: DeliveryStatus): string {
  const map: Record<DeliveryStatus, string> = {
    preparing: "กำลังเตรียมจัดส่ง",
    delivering: "กำลังจัดส่ง",
    delivered: "จัดส่งสำเร็จ ✓",
    cancelled: "ยกเลิก",
  };
  return map[status];
}

export function getStatusColor(status: DeliveryStatus): string {
  const map: Record<DeliveryStatus, string> = {
    preparing: "#F59E0B",
    delivering: "#3B82F6",
    delivered: "#10B981",
    cancelled: "#EF4444",
  };
  return map[status];
}

export function formatOrderDate(isoDate: string): string {
  const d = new Date(isoDate);
  const day = d.getDate().toString().padStart(2, "0");
  const months = ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."];
  const month = months[d.getMonth()];
  const hour = d.getHours().toString().padStart(2, "0");
  const min = d.getMinutes().toString().padStart(2, "0");
  return `${day} ${month} ${hour}:${min}`;
}
