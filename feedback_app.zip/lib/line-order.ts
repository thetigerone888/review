import { Linking } from "react-native";

const LINE_ID = "@marbohub";
const LINE_URL = "https://lin.ee/uxfvSkp";
const MARBOHUB_URL = "https://www.marbohub.com";

/**
 * เปิดหน้าเว็บ marbohub.com สำหรับสั่งซื้อสินค้า
 * ถ้ามี productUrl จะเปิดหน้าสินค้านั้นโดยตรง
 */
export async function openWebOrder(productUrl?: string) {
  const url = productUrl ?? MARBOHUB_URL;
  await Linking.openURL(url);
}

/**
 * สร้าง LINE URL พร้อม pre-filled message สำหรับสั่งซื้อสินค้า
 * เปิด LINE app โดยตรง ถ้าไม่มีแอปจะเปิดเว็บแทน
 */
export function buildLineOrderUrl(message: string): string {
  const encoded = encodeURIComponent(message);
  // LINE URL scheme: line://ti/p/{lineId} จะเปิดแชทโดยตรง
  // ถ้าไม่มีแอป LINE จะ fallback ไปที่ lin.ee
  return `https://line.me/R/oaMessage/${encodeURIComponent(LINE_ID)}/?${encoded}`;
}

/**
 * เปิด LINE พร้อมข้อความสั่งซื้อสินค้าที่ระบุ
 */
export async function openLineOrder(productName: string, price?: number, flavor?: string) {
  let msg = `สวัสดีครับ/ค่ะ 👋 ต้องการสั่งซื้อ\n\n`;
  msg += `📦 สินค้า: ${productName}\n`;
  if (flavor) msg += `🌿 กลิ่น: ${flavor}\n`;
  if (price) msg += `💰 ราคา: ฿${price.toLocaleString()}\n`;
  msg += `\nกรุณาแจ้งที่อยู่จัดส่งและช่องทางชำระเงินด้วยครับ/ค่ะ 🙏`;

  // ลองเปิด LINE app โดยตรงก่อน
  const lineAppUrl = `line://ti/p/${encodeURIComponent(LINE_ID)}`;
  const canOpen = await Linking.canOpenURL(lineAppUrl);
  if (canOpen) {
    await Linking.openURL(lineAppUrl);
  } else {
    // fallback ไปที่ lin.ee
    await Linking.openURL(LINE_URL);
  }
}

/**
 * เปิด LINE พร้อมข้อความทั่วไป (สอบถาม/ติดต่อ)
 */
export async function openLineChat(customMessage?: string) {
  const msg = customMessage ?? `สวัสดีครับ/ค่ะ 👋 ต้องการสอบถามข้อมูลสินค้าครับ/ค่ะ`;
  const lineAppUrl = `line://ti/p/${encodeURIComponent(LINE_ID)}`;
  const canOpen = await Linking.canOpenURL(lineAppUrl);
  if (canOpen) {
    await Linking.openURL(lineAppUrl);
  } else {
    await Linking.openURL(LINE_URL);
  }
}
