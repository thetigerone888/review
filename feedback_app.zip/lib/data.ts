import AsyncStorage from "@react-native-async-storage/async-storage";
import type {
  FeedbackItem,
  FeedbackTag,
  Survey,
  Product,
  ProductCategory,
  DashboardStats,
  NPSTrend,
  TagStat,
  ContactChannel,
  BusinessHours,
} from "./types";

// ============================================================
// Storage Keys
// ============================================================
const KEYS = {
  FEEDBACKS: "feedbackpro_feedbacks",
  TAGS: "feedbackpro_tags",
  SURVEYS: "feedbackpro_surveys",
};

// ============================================================
// Mock Seed Data
// ============================================================
export const DEFAULT_TAGS: FeedbackTag[] = [
  { id: "t1", label: "บริการดี", color: "#10B981" },
  { id: "t2", label: "ราคาเหมาะสม", color: "#4F46E5" },
  { id: "t3", label: "รอนาน", color: "#F59E0B" },
  { id: "t4", label: "สินค้าเสียหาย", color: "#EF4444" },
  { id: "t5", label: "จัดส่งเร็ว", color: "#10B981" },
  { id: "t6", label: "แนะนำเพื่อน", color: "#8B5CF6" },
  { id: "t7", label: "ต้องปรับปรุง", color: "#F59E0B" },
  { id: "t8", label: "ประทับใจ", color: "#10B981" },
];

export const MOCK_FEEDBACKS: FeedbackItem[] = [
  {
    id: "f1",
    customerName: "สมชาย ใจดี",
    customerEmail: "somchai@email.com",
    channel: "survey",
    rating: 5,
    npsScore: 9,
    comment: "บริการดีมาก พนักงานใส่ใจลูกค้า สินค้าคุณภาพดี จะกลับมาซื้ออีกแน่นอน",
    sentiment: "positive",
    sentimentConfidence: 0.95,
    tags: ["t1", "t8"],
    surveyId: "s1",
    productId: "p1",
    createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    isArchived: false,
  },
  {
    id: "f2",
    customerName: "วิไล สุขใส",
    customerEmail: "wilai@email.com",
    channel: "qr",
    rating: 4,
    npsScore: 8,
    comment: "สินค้าดีแต่รอนานนิดหน่อย การจัดส่งควรปรับปรุง",
    sentiment: "neutral",
    sentimentConfidence: 0.78,
    tags: ["t3", "t2"],
    surveyId: "s1",
    createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    isArchived: false,
  },
  {
    id: "f3",
    customerName: "ประเสริฐ มั่นคง",
    channel: "email",
    rating: 2,
    npsScore: 3,
    comment: "สินค้าที่ได้รับมาเสียหาย บรรจุภัณฑ์ไม่แข็งแรง ต้องการเคลม",
    sentiment: "negative",
    sentimentConfidence: 0.92,
    tags: ["t4", "t7"],
    createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    isArchived: false,
  },
  {
    id: "f4",
    customerName: "นภา รักสวย",
    channel: "survey",
    rating: 5,
    npsScore: 10,
    comment: "ประทับใจมากค่ะ จัดส่งเร็ว สินค้าตรงปก แนะนำให้เพื่อนทุกคนเลย",
    sentiment: "positive",
    sentimentConfidence: 0.98,
    tags: ["t5", "t6", "t8"],
    surveyId: "s2",
    productId: "p2",
    createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
    isArchived: false,
  },
  {
    id: "f5",
    customerName: "อนุชา ทองดี",
    channel: "direct",
    rating: 3,
    npsScore: 6,
    comment: "พอใช้ได้ครับ ไม่มีอะไรพิเศษ ราคาก็โอเค",
    sentiment: "neutral",
    sentimentConfidence: 0.65,
    tags: ["t2"],
    createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    isArchived: false,
  },
  {
    id: "f6",
    customerName: "มาลี สดใส",
    channel: "sms",
    rating: 5,
    npsScore: 9,
    comment: "ดีมากเลยค่ะ สินค้าคุณภาพสูง บริการประทับใจ",
    sentiment: "positive",
    sentimentConfidence: 0.91,
    tags: ["t1", "t8"],
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    isArchived: false,
  },
  {
    id: "f7",
    customerName: "สุรชัย เก่งกาจ",
    channel: "survey",
    rating: 1,
    npsScore: 1,
    comment: "แย่มาก สินค้าไม่ตรงกับรูป ต้องการคืนเงิน",
    sentiment: "negative",
    sentimentConfidence: 0.97,
    tags: ["t4", "t7"],
    surveyId: "s1",
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    isArchived: false,
  },
  {
    id: "f8",
    customerName: "กัลยา ใจงาม",
    channel: "qr",
    rating: 4,
    npsScore: 8,
    comment: "ชอบมากค่ะ จะกลับมาซื้ออีก",
    sentiment: "positive",
    sentimentConfidence: 0.88,
    tags: ["t6"],
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    isArchived: false,
  },
];

export const MOCK_SURVEYS: Survey[] = [
  {
    id: "s1",
    title: "แบบสอบถามความพึงพอใจลูกค้า",
    description: "ช่วยเราปรับปรุงบริการด้วยการตอบแบบสอบถามนี้",
    questions: [
      { id: "q1", type: "nps", text: "คุณจะแนะนำเราให้เพื่อนหรือครอบครัวมากน้อยแค่ไหน?", required: true },
      { id: "q2", type: "star", text: "คุณพอใจกับสินค้าของเรามากน้อยแค่ไหน?", required: true },
      { id: "q3", type: "multiple_choice", text: "คุณพบเราได้อย่างไร?", required: false, options: ["โซเชียลมีเดีย", "เพื่อนแนะนำ", "ค้นหาออนไลน์", "โฆษณา", "อื่นๆ"] },
      { id: "q4", type: "open_text", text: "มีข้อเสนอแนะอะไรเพิ่มเติมไหม?", required: false },
    ],
    status: "active",
    channels: ["survey", "qr", "email"],
    responseCount: 45,
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "s2",
    title: "แบบสอบถามหลังการซื้อสินค้า",
    description: "ขอบคุณที่ซื้อสินค้ากับเรา กรุณาแบ่งปันประสบการณ์",
    questions: [
      { id: "q1", type: "star", text: "คุณพอใจกับสินค้าที่ได้รับมากน้อยแค่ไหน?", required: true },
      { id: "q2", type: "nps", text: "คุณจะแนะนำสินค้าของเราให้ผู้อื่นไหม?", required: true },
      { id: "q3", type: "open_text", text: "บอกเล่าประสบการณ์ของคุณ", required: false },
    ],
    status: "active",
    channels: ["sms", "email"],
    responseCount: 28,
    createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "s3",
    title: "แบบสอบถามประสบการณ์การใช้บริการ",
    description: "ช่วยเราพัฒนาการบริการให้ดียิ่งขึ้น",
    questions: [
      { id: "q1", type: "star", text: "คุณพอใจกับการบริการของพนักงานมากน้อยแค่ไหน?", required: true },
      { id: "q2", type: "multiple_choice", text: "ปัญหาที่พบบ่อยคืออะไร?", required: false, options: ["รอนาน", "ราคาสูง", "สินค้าไม่ครบ", "บริการไม่ดี", "ไม่มีปัญหา"] },
    ],
    status: "closed",
    channels: ["direct"],
    responseCount: 62,
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    closedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
  },
];

export const MOCK_PRODUCTS: Product[] = [
  {
    id: "p1",
    name: "Marbo Bar 9000 Puffs",
    description: "พอตใช้แล้วทิ้ง Marbo Bar 9000 คำ มี 18 กลิ่นให้เลือก ส่งด่วนทันใจ ของแท้ 100%",
    price: 420,
    imageUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663404651396/kEFtBHqHAKISifdL.webp",
    categoryId: "c1",
    rating: 4.8,
    reviewCount: 124,
    inStock: true,
    flavors: ["Mango", "Watermelon", "Grape", "Lychee", "Strawberry", "Blueberry", "Peach", "Cola", "Mint", "Mixed Berry"],
    puffs: 9000,
    brand: "MARBO / SALTHUB",
    productUrl: "https://www.marbohub.com/product/4H7FmeWIYVhlCpoSVHqo",
  },
  {
    id: "p2",
    name: "CKS Pulse 15000 Puffs",
    description: "พอตใช้แล้วทิ้ง CKS Pulse 15000 คำ มี 15 กลิ่นให้เลือก ส่งด่วน ราคาพิเศษ",
    price: 399,
    imageUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663404651396/oOyDbzEOFpbgMIOX.webp",
    categoryId: "c2",
    rating: 4.7,
    reviewCount: 89,
    inStock: true,
    flavors: ["Pineapple Tea", "Watermelon", "Grape", "Strawberry", "Mango", "Blueberry", "Lychee", "Peach", "Cola"],
    puffs: 15000,
    brand: "CKS",
    productUrl: "https://www.marbohub.com/product/HkCbCZ3wOAYcD4ui9vsP",
  },
  {
    id: "p3",
    name: "SKE Crystal",
    description: "พอตใช้แล้วทิ้ง SKE Crystal มี 7 กลิ่นให้เลือก ดีไซน์สวย ส่งด่วน ของแท้",
    price: 399,
    imageUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663404651396/iKMytCsFOTXrezFz.webp",
    categoryId: "c3",
    rating: 4.6,
    reviewCount: 67,
    inStock: true,
    flavors: ["Watermelon Ice", "Blueberry", "Strawberry Kiwi", "Grape", "Peach Mango", "Lemon Lime", "Mixed Berry"],
    puffs: 600,
    brand: "SKE CRYSTAL",
    productUrl: "https://www.marbohub.com/product/PqvBy9IVbwlPL3jp3Jmh",
  },
  {
    id: "p4",
    name: "RELX SMASH GO",
    description: "พอตใช้แล้วทิ้ง RELX SMASH GO 12000 คำ มี 14 กลิ่นให้เลือก ส่งด่วนทันใจ",
    price: 400,
    imageUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663404651396/AGVkycSggZgaHSgV.webp",
    categoryId: "c2",
    rating: 4.7,
    reviewCount: 156,
    inStock: true,
    flavors: ["Grape", "Double Mint", "Cool Mint", "Cola", "Mix Berry", "Peach Strawberry", "Grape Lychee", "Watermelon", "Apple", "Passion Fruit", "Mango"],
    puffs: 12000,
    brand: "RELX",
    productUrl: "https://www.marbohub.com/product/Vo28emodFL3d0d5ylrQm",
  },
  {
    id: "p5",
    name: "Escobar 20000PUFFS",
    description: "พอตใช้แล้วทิ้ง ESKO BAR 20000 คำ Dual Mesh Coil + Type-C มี 13 กลิ่น ส่งด่วน",
    price: 420,
    imageUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663404651396/UCEHaKpuGNmdYxxp.webp",
    categoryId: "c1",
    rating: 4.8,
    reviewCount: 203,
    inStock: true,
    flavors: ["Berry Grape", "Watermelon Strawberry", "Blueberry Ice", "Strawberry Banana", "Pink Guava", "Bubblegum", "Strawberry Kiwi", "Watermelon Ice", "Mixberry", "Cola", "Sour Strawberry", "E Melon", "Apple Aloe"],
    puffs: 20000,
    brand: "ESCO BAR",
    productUrl: "https://www.marbohub.com/product/odqgi8eJKSvJOaq73kKt",
  },
  {
    id: "p6",
    name: "Marbo MSwitch M15KIT",
    description: "Starter Kit Marbo MSwitch M15K พร้อมหัวพอด มี 8 กลิ่นให้เลือก ส่งด่วน ของแท้",
    price: 727,
    imageUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663404651396/wjTXbReVvezNUlVw.webp",
    categoryId: "c4",
    rating: 4.9,
    reviewCount: 78,
    inStock: true,
    flavors: ["Peach Strawberry", "Blackberry", "Strawberry", "Pinkberry", "Apple Aloe", "Cola", "Watermelon Bubblegum", "Grape Lychee"],
    puffs: 15000,
    brand: "MARBO / SALTHUB",
    productUrl: "https://www.marbohub.com/product/uN3wkLwRooQR8TxU4BkC",
  },
  {
    id: "p7",
    name: "Marbo Zero Pod",
    description: "หัวพอด Marbo Zero มี 9 กลิ่นให้เลือก ราคาประหยัด ส่งด่วน ของแท้ 100%",
    price: 160,
    imageUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663404651396/kEFtBHqHAKISifdL.webp",
    categoryId: "c5",
    rating: 4.5,
    reviewCount: 45,
    inStock: true,
    flavors: ["Watermelon", "Grape", "Strawberry", "Mango", "Lychee", "Blueberry", "Peach", "Cola", "Mint"],
    brand: "MARBO / SALTHUB",
    productUrl: "https://www.marbohub.com/",
  },
  {
    id: "p8",
    name: "RELX Pro2 (หัวพอด)",
    description: "หัวพอด RELX Pro2 มี 14 กลิ่นให้เลือก ราคาประหยัด ส่งด่วน ของแท้ 100%",
    price: 160,
    imageUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663404651396/AGVkycSggZgaHSgV.webp",
    categoryId: "c5",
    rating: 4.6,
    reviewCount: 92,
    inStock: true,
    flavors: ["Grape", "Double Mint", "Cool Mint", "Cola", "Mix Berry", "Peach Strawberry", "Grape Lychee", "Watermelon", "Apple", "Passion Fruit", "Mango", "Lemon", "Pineapple", "Coconut"],
    brand: "RELX",
    productUrl: "https://www.marbohub.com/",
  },
];

export const PRODUCT_CATEGORIES: ProductCategory[] = [
  { id: "all", name: "ทั้งหมด" },
  { id: "c1", name: "ESCO BAR" },
  { id: "c2", name: "RELX" },
  { id: "c3", name: "SKE CRYSTAL" },
  { id: "c4", name: "MARBO / SALTHUB" },
  { id: "c5", name: "หัวพอด" },
];

export const CONTACT_CHANNELS: ContactChannel[] = [
  { id: "ch1", type: "website", label: "เว็บไซต์", value: "www.marbohub.com", icon: "language" },
  { id: "ch2", type: "line", label: "LINE (ติดต่อแอดมิน)", value: "https://lin.ee/uxfvSkp", icon: "chat" },
  { id: "ch3", type: "facebook", label: "Facebook", value: "MarboHub", icon: "facebook" },
  { id: "ch4", type: "email", label: "อีเมล", value: "admin@marbohub.com", icon: "email" },
];

export const BUSINESS_HOURS: BusinessHours[] = [
  { day: "ทุกวัน (จันทร์ - อาทิตย์)", open: "00:00", close: "23:59", closed: false },
  { day: "วันหยุดนักขัตฤกษ์", open: "00:00", close: "23:59", closed: false },
];

// ============================================================
// Dashboard Stats (computed from feedbacks)
// ============================================================
export function computeStats(feedbacks: FeedbackItem[]): DashboardStats {
  const active = feedbacks.filter((f) => !f.isArchived);
  if (active.length === 0) {
    return { totalResponses: 0, npsScore: 0, avgRating: 0, responseRate: 0, positiveCount: 0, neutralCount: 0, negativeCount: 0 };
  }
  const withNPS = active.filter((f) => f.npsScore !== undefined);
  const promoters = withNPS.filter((f) => (f.npsScore ?? 0) >= 9).length;
  const detractors = withNPS.filter((f) => (f.npsScore ?? 0) <= 6).length;
  const npsScore = withNPS.length > 0 ? Math.round(((promoters - detractors) / withNPS.length) * 100) : 0;
  const avgRating = active.reduce((sum, f) => sum + f.rating, 0) / active.length;
  return {
    totalResponses: active.length,
    npsScore,
    avgRating: Math.round(avgRating * 10) / 10,
    responseRate: 78,
    positiveCount: active.filter((f) => f.sentiment === "positive").length,
    neutralCount: active.filter((f) => f.sentiment === "neutral").length,
    negativeCount: active.filter((f) => f.sentiment === "negative").length,
  };
}

export function computeNPSTrend(): NPSTrend[] {
  const now = Date.now();
  return [
    { date: "20 มี.ค.", score: 42 },
    { date: "21 มี.ค.", score: 48 },
    { date: "22 มี.ค.", score: 45 },
    { date: "23 มี.ค.", score: 52 },
    { date: "24 มี.ค.", score: 58 },
    { date: "25 มี.ค.", score: 55 },
    { date: "26 มี.ค.", score: 62 },
  ];
}

export function computeTagStats(feedbacks: FeedbackItem[], tags: FeedbackTag[]): TagStat[] {
  const counts: Record<string, number> = {};
  feedbacks.forEach((f) => {
    f.tags.forEach((tagId) => {
      counts[tagId] = (counts[tagId] ?? 0) + 1;
    });
  });
  return tags
    .map((tag) => ({ tagId: tag.id, label: tag.label, count: counts[tag.id] ?? 0 }))
    .filter((t) => t.count > 0)
    .sort((a, b) => b.count - a.count);
}

// ============================================================
// AsyncStorage Helpers
// ============================================================
export async function loadFeedbacks(): Promise<FeedbackItem[]> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.FEEDBACKS);
    if (raw) return JSON.parse(raw) as FeedbackItem[];
    await AsyncStorage.setItem(KEYS.FEEDBACKS, JSON.stringify(MOCK_FEEDBACKS));
    return MOCK_FEEDBACKS;
  } catch {
    return MOCK_FEEDBACKS;
  }
}

export async function saveFeedbacks(feedbacks: FeedbackItem[]): Promise<void> {
  await AsyncStorage.setItem(KEYS.FEEDBACKS, JSON.stringify(feedbacks));
}

export async function loadTags(): Promise<FeedbackTag[]> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.TAGS);
    if (raw) return JSON.parse(raw) as FeedbackTag[];
    await AsyncStorage.setItem(KEYS.TAGS, JSON.stringify(DEFAULT_TAGS));
    return DEFAULT_TAGS;
  } catch {
    return DEFAULT_TAGS;
  }
}

export async function saveTags(tags: FeedbackTag[]): Promise<void> {
  await AsyncStorage.setItem(KEYS.TAGS, JSON.stringify(tags));
}

export async function loadSurveys(): Promise<Survey[]> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.SURVEYS);
    if (raw) return JSON.parse(raw) as Survey[];
    await AsyncStorage.setItem(KEYS.SURVEYS, JSON.stringify(MOCK_SURVEYS));
    return MOCK_SURVEYS;
  } catch {
    return MOCK_SURVEYS;
  }
}

export async function saveSurveys(surveys: Survey[]): Promise<void> {
  await AsyncStorage.setItem(KEYS.SURVEYS, JSON.stringify(surveys));
}

// ============================================================
// Sentiment Analysis (local heuristic)
// ============================================================
const POSITIVE_WORDS = ["ดี", "ดีมาก", "ประทับใจ", "ชอบ", "แนะนำ", "เร็ว", "คุณภาพ", "สุดยอด", "เยี่ยม", "พอใจ", "ขอบคุณ"];
const NEGATIVE_WORDS = ["แย่", "เสียหาย", "ผิดหวัง", "ช้า", "ปัญหา", "เคลม", "คืนเงิน", "ไม่พอใจ", "ไม่ดี", "เสีย"];

export function analyzeSentiment(text: string): { sentiment: "positive" | "neutral" | "negative"; confidence: number } {
  const lower = text.toLowerCase();
  let posScore = 0;
  let negScore = 0;
  POSITIVE_WORDS.forEach((w) => { if (lower.includes(w)) posScore++; });
  NEGATIVE_WORDS.forEach((w) => { if (lower.includes(w)) negScore++; });
  const total = posScore + negScore;
  if (total === 0) return { sentiment: "neutral", confidence: 0.6 };
  if (posScore > negScore) return { sentiment: "positive", confidence: Math.min(0.6 + posScore * 0.1, 0.98) };
  if (negScore > posScore) return { sentiment: "negative", confidence: Math.min(0.6 + negScore * 0.1, 0.98) };
  return { sentiment: "neutral", confidence: 0.65 };
}

// ============================================================
// Export to CSV
// ============================================================
export function exportFeedbacksToCSV(feedbacks: FeedbackItem[], tags: FeedbackTag[]): string {
  const tagMap = Object.fromEntries(tags.map((t) => [t.id, t.label]));
  const header = "ID,ชื่อลูกค้า,อีเมล,ช่องทาง,คะแนน,NPS,ความรู้สึก,แท็ก,ความคิดเห็น,วันที่\n";
  const rows = feedbacks.map((f) => {
    const tagLabels = f.tags.map((id) => tagMap[id] ?? id).join("|");
    const date = new Date(f.createdAt).toLocaleDateString("th-TH");
    return `${f.id},"${f.customerName}","${f.customerEmail ?? ""}",${f.channel},${f.rating},${f.npsScore ?? ""},${f.sentiment},"${tagLabels}","${f.comment.replace(/"/g, '""')}",${date}`;
  });
  return header + rows.join("\n");
}
