// ============================================================
// Data Models for FeedbackPro App
// ============================================================

export type SentimentType = "positive" | "neutral" | "negative";
export type QuestionType = "nps" | "star" | "multiple_choice" | "open_text";
export type SurveyStatus = "active" | "closed" | "draft";
export type FeedbackChannel = "survey" | "email" | "sms" | "qr" | "direct";

// ---- Feedback ----
export interface FeedbackTag {
  id: string;
  label: string;
  color: string;
}

export interface FeedbackItem {
  id: string;
  customerName: string;
  customerEmail?: string;
  channel: FeedbackChannel;
  rating: number; // 1-5
  npsScore?: number; // 0-10
  comment: string;
  sentiment: SentimentType;
  sentimentConfidence: number; // 0-1
  tags: string[]; // tag ids
  surveyId?: string;
  productId?: string;
  createdAt: string; // ISO date
  isArchived: boolean;
}

// ---- Survey ----
export interface SurveyQuestion {
  id: string;
  type: QuestionType;
  text: string;
  required: boolean;
  options?: string[]; // for multiple_choice
}

export interface Survey {
  id: string;
  title: string;
  description?: string;
  questions: SurveyQuestion[];
  status: SurveyStatus;
  channels: FeedbackChannel[];
  responseCount: number;
  createdAt: string;
  closedAt?: string;
}

export interface SurveyResponse {
  id: string;
  surveyId: string;
  answers: Record<string, string | number>; // questionId -> answer
  submittedAt: string;
}

// ---- Product ----
export interface ProductCategory {
  id: string;
  name: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  categoryId: string;
  rating: number;
  reviewCount: number;
  inStock: boolean;
  // MARBOHUB-specific fields
  flavors?: string[];
  puffs?: number;
  brand?: string;
  productUrl?: string;
}

// ---- Analytics ----
export interface DashboardStats {
  totalResponses: number;
  npsScore: number;
  avgRating: number;
  responseRate: number;
  positiveCount: number;
  neutralCount: number;
  negativeCount: number;
}

export interface NPSTrend {
  date: string;
  score: number;
}

export interface TagStat {
  tagId: string;
  label: string;
  count: number;
}

// ---- Contact ----
export interface ContactChannel {
  id: string;
  type: "phone" | "email" | "line" | "facebook" | "website" | "instagram";
  label: string;
  value: string;
  icon: string;
}

export interface BusinessHours {
  day: string;
  open: string;
  close: string;
  closed: boolean;
}
