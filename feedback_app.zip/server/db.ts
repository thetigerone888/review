import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ── Review queries ──────────────────────────────────────────
import { reviews, InsertReview, Review } from "../drizzle/schema";
import { desc, sql, count, avg } from "drizzle-orm";

export async function createReview(data: InsertReview): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [result] = await db.insert(reviews).values(data).$returningId();
  return result.id;
}

export async function getReviews(limit = 50, offset = 0): Promise<Review[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(limit).offset(offset);
}

export async function getReviewStats() {
  const db = await getDb();
  if (!db) return { totalReviews: 0, avgRating: 0, npsScore: 0, sentimentBreakdown: { positive: 0, neutral: 0, negative: 0 } };

  const [stats] = await db.select({
    totalReviews: count(),
    avgRating: avg(reviews.rating),
  }).from(reviews);

  // Sentiment breakdown
  const sentimentRows = await db.select({
    sentiment: reviews.sentiment,
    cnt: count(),
  }).from(reviews).groupBy(reviews.sentiment);

  const sentimentBreakdown = { positive: 0, neutral: 0, negative: 0 };
  for (const row of sentimentRows) {
    if (row.sentiment === "positive") sentimentBreakdown.positive = row.cnt;
    else if (row.sentiment === "neutral") sentimentBreakdown.neutral = row.cnt;
    else if (row.sentiment === "negative") sentimentBreakdown.negative = row.cnt;
  }

  // NPS calculation
  const npsRows = await db.select({
    npsScore: reviews.npsScore,
  }).from(reviews).where(sql`${reviews.npsScore} IS NOT NULL`);

  let promoters = 0, detractors = 0;
  for (const row of npsRows) {
    if (row.npsScore !== null && row.npsScore >= 9) promoters++;
    else if (row.npsScore !== null && row.npsScore <= 6) detractors++;
  }
  const npsTotal = npsRows.length;
  const npsScore = npsTotal > 0 ? Math.round(((promoters - detractors) / npsTotal) * 100) : 0;

  return {
    totalReviews: stats.totalReviews,
    avgRating: stats.avgRating ? parseFloat(String(stats.avgRating)) : 0,
    npsScore,
    sentimentBreakdown,
  };
}
