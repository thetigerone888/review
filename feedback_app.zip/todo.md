# Customer Feedback App — TODO

## Setup & Branding
- [x] สร้างโลโก้แอปและตั้งค่า icon
- [x] อัปเดต theme colors (Indigo brand)
- [x] ตั้งค่า app name และ config

## Navigation & Structure
- [x] ตั้งค่า Tab navigation (5 tabs: Dashboard, Feedback, Survey, Catalog, Contact)
- [x] เพิ่ม icon mapping ใน icon-symbol.tsx
- [x] สร้าง data models และ AsyncStorage helpers

## Dashboard Screen
- [x] KPI Cards (Total Responses, NPS Score, Avg Rating, Response Rate)
- [x] Sentiment overview chart
- [x] NPS trend chart (7 days)
- [x] Recent feedback list
- [x] Pull-to-refresh
- [x] Quick action button (Create Survey)

## Feedback Screen
- [x] Feedback list with FeedbackCard component
- [x] Search bar
- [x] Filter chips (All/Positive/Neutral/Negative/Tagged)
- [x] Sort options (Latest/Oldest/Rating)
- [x] Export button (CSV)

## Feedback Detail Screen
- [x] Full feedback display
- [x] Sentiment analysis badge with confidence
- [x] NPS score display with category (Promoter/Passive/Detractor)
- [x] Tags add/remove functionality
- [x] Archive action

## Survey Screen
- [x] Survey list with status badges
- [x] Create Survey modal (NPS, Star, Multiple Choice, Open Text)
- [x] Share options (Copy Link, QR Code)
- [x] Survey status toggle (Active/Closed)
- [x] Survey stats (responses, questions, channels)

## Survey Fill Screen
- [x] NPS scale (0-10) with color coding
- [x] Star rating (1-5)
- [x] Multiple choice questions
- [x] Open text questions
- [x] Progress bar
- [x] Submit and thank you screen

## Analytics Screen
- [x] Date range picker (7d/30d/90d)
- [x] Summary stats grid
- [x] NPS trend chart
- [x] Sentiment breakdown chart
- [x] Response volume chart
- [x] Top tags list with bars
- [x] NPS group breakdown (Promoters/Passives/Detractors)
- [x] Export report (CSV)

## Catalog Screen
- [x] Product grid (2 columns)
- [x] Category filter chips
- [x] Search bar
- [x] Featured products section (horizontal scroll)
- [x] Out-of-stock badge

## Product Detail Screen
- [x] Product image and info
- [x] Star rating display
- [x] Customer reviews section
- [x] "Leave Feedback" button

## Contact Screen
- [x] Company info card
- [x] Contact channels (Phone, Email, LINE, Facebook, Website, Instagram)
- [x] Business hours table
- [x] Location card
- [x] Contact form (Name, Email, Message)

## Components
- [x] FeedbackCard component
- [x] KPICard component
- [x] SentimentBadge component
- [x] StarRating component
- [x] TagChip component

## MARBOHUB Integration
- [x] ดึงข้อมูลสินค้าจริงจาก www.MARBOHUB.com (8 รายการ)
- [x] อัปเดต Product type ให้รองรับ flavors, puffs, brand, productUrl
- [x] แสดง brand badge และ puffs badge ในการ์ดสินค้า
- [x] แสดงรายการกลิ่นทั้งหมดใน Product Detail
- [x] ปุ่ม "สั่งซื้อที่ MarboHub.com" ลิงก์ไปหน้าสินค้าจริง
- [x] อัปเดตหมวดหมู่สินค้า (ESCO BAR, RELX, SKE CRYSTAL, MARBO/SALTHUB, หัวพอด)
- [x] อัปเดตช่องทางติดต่อ (Website, LINE, Facebook, Email)
- [x] อัปเดตเวลาทำการ (09:00-22:00 ทุกวัน)
- [x] อัปเดต Company Info เป็น MarboHub

## LINE & Knowledge Page
- [x] สร้าง LineFloatingButton component (ทุกหน้า)
- [x] อัปเดต contact channels เพิ่ม LINE lin.ee/80tlOG1
- [x] สร้างหน้า Knowledge (tab ใหม่) เกี่ยวกับบุหรี่ไฟฟ้า
- [x] เพิ่มบทความให้ความรู้ (ประเภทพอต, วิธีใช้, ความปลอดภัย, FAQ)
- [x] เพิ่ม icon สำหรับ Knowledge tab

## Knowledge First + Photo Review
- [x] ย้าย Knowledge tab มาเป็น Tab แรก (index)
- [ ] เพิ่มส่วน Photo Review ด้านล่างหน้าความรู้ (ถ่ายรูป + รีวิว)
- [ ] ใช้ expo-image-picker สำหรับถ่ายรูปหรือเลือกจาก gallery
- [ ] แสดงรูปที่ถ่ายพร้อม form รีวิว (ชื่อ, คะแนน, ความคิดเห็น)
- [ ] บันทึก photo review ลง AsyncStorage

## Delivery Proof Section
- [ ] สำรวจหน้า admin/sales เพื่อดูโครงสร้างข้อมูล
- [ ] สร้าง DeliveryProof section/หน้าแสดงหลักฐานการจัดส่ง
- [ ] ปิดข้อมูลส่วนตัวลูกค้า (ชื่อ, เบอร์, ที่อยู่)
- [ ] แสดงข้อมูลที่เปิดได้: สินค้า, วันที่, สถานะ, เลขพัสดุ
- [ ] เพิ่มหน้า Delivery Proof เป็น section ในแอป

## LINE URL Update + Delivery Proof
- [x] อัปเดต LINE URL เป็น https://lin.ee/uxfvSkp ทุกจุด
- [x] ล็อกอิน admin/sales และดึงข้อมูลการจัดส่ง
- [x] สร้าง Delivery Proof section แสดงหลักฐานการส่ง (ปิดข้อมูลส่วนตัว)
- [x] ย้าย Knowledge tab มาเป็น Tab แรก
- [x] เพิ่ม Photo Review section ด้านล่างหน้าแรก

## Knowledge Search & Filter
- [ ] เพิ่ม Search bar ค้นหาบทความด้วยชื่อ/เนื้อหา
- [x] เพิ่มปุ่มกรองหมวดหมู่ (chip filter) แบบ horizontal scroll
- [x] เพิ่ม sort (ล่าสุด / ยอดนิยม / เวลาอ่าน)
- [ ] แสดงจำนวนผลลัพธ์และสถานะ "ไม่พบบทความ"

## LINE Order System (เนียนๆ)
- [ ] เพิ่มปุ่ม "สั่งซื้อผ่าน LINE" ในการ์ดสินค้าบน catalog พร้อม pre-filled message ชื่อสินค้า
- [ ] เพิ่มปุ่ม "สั่งซื้อเลย" ขนาดใหญ่ใน Product Detail พร้อม deep-link ข้อความสั่งซื้อ
- [ ] เพิ่ม LINE Order Banner ในหน้าแรก (knowledge tab)
- [ ] เพิ่มปุ่มสั่งซื้อในบทความที่เกี่ยวกับสินค้า
- [ ] สร้าง helper function สร้าง LINE URL พร้อม pre-filled message

## Knowledge Search & Filter
- [ ] เพิ่ม Search bar ค้นหาบทความด้วยชื่อ/เนื้อหา/แท็ก
- [x] เพิ่มปุ่มกรองหมวดหมู่ (chip filter) แบบ horizontal scroll
- [x] เพิ่ม sort (ล่าสุด / ยอดนิยม / เวลาอ่าน)
- [x] แสดงจำนวนผลลัพธ์และสถานะ "ไม่พบบทความ" พร้อมปุ่มล้างการค้นหา

## เปลี่ยนปุ่มสั่งซื้อในหน้าสินค้า
- [ ] เปลี่ยนปุ่ม LINE สั่งซื้อในการ์ดสินค้า (catalog) เป็น "สั่งหน้าเว็บ" ลิงก์ไป marbohub.com
- [ ] เปลี่ยนปุ่ม LINE สั่งซื้อใน Product Detail เป็น "สั่งหน้าเว็บ" ลิงก์ไปหน้าสินค้าจริง
- [ ] ลบ/ซ่อน LINE order banner ใน catalog header ที่ชวนสั่งซื้อผ่าน LINE

## ปรับปุ่มสั่งซื้อในหน้าสินค้า
- [x] catalog: เปลี่ยนปุ่ม "สั่งผ่าน LINE" ในการ์ดสินค้าเป็น "สั่งหน้าเว็บ" ลิงก์ไป marbohub.com
- [x] catalog: เปลี่ยน banner "สั่งซื้อผ่าน LINE" ใน header เป็น "ดูสินค้าทั้งหมดที่เว็บ" ลิงก์ไป marbohub.com
- [x] catalog: เปลี่ยนปุ่ม LINE ใน FeaturedCard เป็น "เว็บ" ลิงก์ไป marbohub.com
- [x] product detail: เปลี่ยนปุ่มใหญ่ "สั่งซื้อผ่าน LINE เลย!" เป็น "สั่งหน้าเว็บ" ลิงก์ไปหน้าสินค้าจริง
- [x] product detail: เพิ่มปุ่ม "ทักแชท LINE" เป็นปุ่มรองสำหรับสอบถาม
- [x] คง LINE floating button ทุกหน้าไว้ตามเดิม

## ปรับหน้าสินค้าเป็นแคตตาล็อก (ไม่ใช่ร้านค้า)
- [ ] catalog: ซ่อนราคาสินค้าในการ์ด
- [ ] catalog: ลบปุ่ม "สั่งหน้าเว็บ" ออกจากการ์ดสินค้า
- [ ] catalog: เปลี่ยน header/banner เป็นสไตล์แคตตาล็อก
- [ ] catalog: เปลี่ยนชื่อ Tab เป็น "แคตตาล็อก"
- [ ] product detail: ซ่อนราคา
- [ ] product detail: ลบปุ่ม "สั่งหน้าเว็บ" ออก
- [ ] product detail: เพิ่มปุ่ม "ดูรายละเอียดที่เว็บ" ที่ลิงก์ไป marbohub.com
- [ ] product detail: คงปุ่ม "ทักแชท LINE" ไว้สำหรับสอบถาม

## ปรับปุ่มสินค้าให้ชัดเจน 2 ปุ่ม
- [x] product detail: ปุ่มหลัก "สั่งซื้อหน้าเว็บ" ลิงก์ไป marbohub.com
- [x] product detail: ปุ่มรอง "LINE ติดต่อสอบถามข้อมูลเพิ่มเติม" เปิด LINE @marbohub
- [x] catalog: ปุ่มในการ์ดสินค้าเป็น "ดูรายละเอียด" ไม่ใช่สั่งซื้อ

## ทำแอปรีวิวใช้งานได้จริง (ลูกค้าส่งรีวิวผ่านลิงก์)
- [ ] สร้าง database schema สำหรับรีวิว (reviews table)
- [ ] สร้าง tRPC API endpoints: submitReview, getReviews, getReviewStats
- [ ] อัปเดตหน้ารีวิวให้ใช้ database จริง แทน mock data
- [ ] สร้างฟอร์มส่งรีวิว (ชื่อ, ดาว, ข้อความ, สินค้า) ที่ลูกค้าเข้าถึงได้ผ่านลิงก์
- [ ] ทำหน้าแดชบอร์ดแสดงรีวิวจริงจาก DB (คะแนนเฉลี่ย, จำนวน, NPS)
- [ ] ทดสอบ flow ครบถ้วน: ส่งรีวิว → แสดงในแดชบอร์ด
