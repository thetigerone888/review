/** @type {const} */
const themeColors = {
  primary:    { light: '#1A56DB', dark: '#3B82F6' },
  background: { light: '#ffffff', dark: '#0A0F1E' },
  surface:    { light: '#EFF6FF', dark: '#111827' },
  foreground: { light: '#0A0F1E', dark: '#F0F6FF' },
  muted:      { light: '#6B7280', dark: '#9CA3AF' },
  border:     { light: '#BFDBFE', dark: '#1E3A5F' },
  success:    { light: '#22C55E', dark: '#4ADE80' },
  warning:    { light: '#F59E0B', dark: '#FBBF24' },
  error:      { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
