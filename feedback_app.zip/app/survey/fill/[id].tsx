import {
  View, Text, ScrollView, Pressable, StyleSheet, TextInput, Alert
} from "react-native";
import { useState, useEffect } from "react";
import { useLocalSearchParams, router } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { StarRating } from "@/components/ui/star-rating";
import { useColors } from "@/hooks/use-colors";
import { loadSurveys, loadFeedbacks, saveFeedbacks, analyzeSentiment } from "@/lib/data";
import type { Survey, FeedbackItem } from "@/lib/types";

export default function SurveyFillScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const [survey, setSurvey] = useState<Survey | null>(null);
  const [answers, setAnswers] = useState<Record<string, string | number>>({});
  const [currentQ, setCurrentQ] = useState(0);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    (async () => {
      const surveys = await loadSurveys();
      setSurvey(surveys.find((s) => s.id === id) ?? null);
    })();
  }, [id]);

  if (!survey) {
    return (
      <ScreenContainer>
        <View style={styles.loading}>
          <Text style={{ color: colors.muted }}>กำลังโหลด...</Text>
        </View>
      </ScreenContainer>
    );
  }

  if (submitted) {
    return (
      <ScreenContainer>
        <View style={styles.thankYou}>
          <Text style={styles.thankEmoji}>🎉</Text>
          <Text style={[styles.thankTitle, { color: colors.foreground }]}>ขอบคุณมาก!</Text>
          <Text style={[styles.thankSub, { color: colors.muted }]}>
            ความคิดเห็นของคุณมีคุณค่ามากสำหรับเรา
          </Text>
          <Pressable
            onPress={() => router.back()}
            style={[styles.doneBtn, { backgroundColor: colors.primary }]}
          >
            <Text style={styles.doneBtnText}>กลับหน้าหลัก</Text>
          </Pressable>
        </View>
      </ScreenContainer>
    );
  }

  const question = survey.questions[currentQ];
  const progress = ((currentQ + 1) / survey.questions.length) * 100;
  const currentAnswer = answers[question.id];
  const canProceed = !question.required || currentAnswer !== undefined;

  const handleNext = async () => {
    if (currentQ < survey.questions.length - 1) {
      setCurrentQ(currentQ + 1);
    } else {
      // Submit
      const npsQ = survey.questions.find((q) => q.type === "nps");
      const starQ = survey.questions.find((q) => q.type === "star");
      const textQ = survey.questions.find((q) => q.type === "open_text");
      const comment = textQ ? String(answers[textQ.id] ?? "") : "ส่งแบบสอบถาม";
      const sentimentResult = analyzeSentiment(comment);

      const newFeedback: FeedbackItem = {
        id: `f${Date.now()}`,
        customerName: "ลูกค้า",
        channel: "survey",
        rating: starQ ? Number(answers[starQ.id] ?? 3) : 3,
        npsScore: npsQ ? Number(answers[npsQ.id]) : undefined,
        comment: comment || "ส่งแบบสอบถาม",
        sentiment: sentimentResult.sentiment,
        sentimentConfidence: sentimentResult.confidence,
        tags: [],
        surveyId: survey.id,
        createdAt: new Date().toISOString(),
        isArchived: false,
      };

      const all = await loadFeedbacks();
      await saveFeedbacks([newFeedback, ...all]);
      setSubmitted(true);
    }
  };

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="xmark" size={20} color={colors.muted} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={[styles.surveyTitle, { color: colors.foreground }]} numberOfLines={1}>
            {survey.title}
          </Text>
          <Text style={[styles.progress, { color: colors.muted }]}>
            {currentQ + 1} / {survey.questions.length}
          </Text>
        </View>
      </View>

      {/* Progress Bar */}
      <View style={[styles.progressTrack, { backgroundColor: colors.border }]}>
        <View style={[styles.progressFill, { width: `${progress}%`, backgroundColor: colors.primary }]} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={[styles.questionText, { color: colors.foreground }]}>
          {question.text}
          {question.required && <Text style={{ color: colors.error }}> *</Text>}
        </Text>

        {/* NPS Scale */}
        {question.type === "nps" && (
          <View style={styles.npsContainer}>
            <View style={styles.npsScale}>
              {Array.from({ length: 11 }, (_, i) => (
                <Pressable
                  key={i}
                  onPress={() => setAnswers({ ...answers, [question.id]: i })}
                  style={[
                    styles.npsBtn,
                    {
                      backgroundColor: currentAnswer === i
                        ? getNPSColor(i)
                        : `${getNPSColor(i)}20`,
                      borderColor: getNPSColor(i),
                    },
                  ]}
                >
                  <Text style={[styles.npsNum, { color: currentAnswer === i ? "#FFFFFF" : getNPSColor(i) }]}>
                    {i}
                  </Text>
                </Pressable>
              ))}
            </View>
            <View style={styles.npsLabels}>
              <Text style={[styles.npsLabelText, { color: colors.muted }]}>ไม่แนะนำเลย</Text>
              <Text style={[styles.npsLabelText, { color: colors.muted }]}>แนะนำอย่างยิ่ง</Text>
            </View>
          </View>
        )}

        {/* Star Rating */}
        {question.type === "star" && (
          <View style={styles.starContainer}>
            <StarRating
              value={Number(currentAnswer ?? 0)}
              onChange={(v) => setAnswers({ ...answers, [question.id]: v })}
              size={48}
            />
            {currentAnswer !== undefined && (
              <Text style={[styles.starLabel, { color: colors.muted }]}>
                {["", "แย่มาก", "แย่", "พอใช้", "ดี", "ดีมาก"][Number(currentAnswer)]}
              </Text>
            )}
          </View>
        )}

        {/* Multiple Choice */}
        {question.type === "multiple_choice" && question.options && (
          <View style={styles.choiceList}>
            {question.options.map((opt) => (
              <Pressable
                key={opt}
                onPress={() => setAnswers({ ...answers, [question.id]: opt })}
                style={[
                  styles.choiceItem,
                  {
                    backgroundColor: currentAnswer === opt ? `${colors.primary}15` : colors.surface,
                    borderColor: currentAnswer === opt ? colors.primary : colors.border,
                  },
                ]}
              >
                <View style={[
                  styles.choiceRadio,
                  {
                    borderColor: currentAnswer === opt ? colors.primary : colors.border,
                    backgroundColor: currentAnswer === opt ? colors.primary : "transparent",
                  },
                ]}>
                  {currentAnswer === opt && <View style={styles.choiceRadioDot} />}
                </View>
                <Text style={[styles.choiceText, { color: colors.foreground }]}>{opt}</Text>
              </Pressable>
            ))}
          </View>
        )}

        {/* Open Text */}
        {question.type === "open_text" && (
          <TextInput
            style={[styles.textArea, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground }]}
            placeholder="พิมพ์ความคิดเห็นของคุณที่นี่..."
            placeholderTextColor={colors.muted}
            value={String(currentAnswer ?? "")}
            onChangeText={(v) => setAnswers({ ...answers, [question.id]: v })}
            multiline
            numberOfLines={5}
            textAlignVertical="top"
          />
        )}
      </ScrollView>

      {/* Navigation */}
      <View style={[styles.footer, { borderTopColor: colors.border }]}>
        {currentQ > 0 && (
          <Pressable
            onPress={() => setCurrentQ(currentQ - 1)}
            style={[styles.prevBtn, { borderColor: colors.border }]}
          >
            <IconSymbol name="chevron.left" size={18} color={colors.foreground} />
            <Text style={[styles.prevText, { color: colors.foreground }]}>ก่อนหน้า</Text>
          </Pressable>
        )}
        <Pressable
          onPress={handleNext}
          style={[
            styles.nextBtn,
            { backgroundColor: canProceed ? colors.primary : colors.border },
            { flex: currentQ > 0 ? 1 : undefined },
          ]}
          disabled={!canProceed}
        >
          <Text style={[styles.nextText, { color: canProceed ? "#FFFFFF" : colors.muted }]}>
            {currentQ === survey.questions.length - 1 ? "ส่งแบบสอบถาม" : "ถัดไป"}
          </Text>
          {currentQ < survey.questions.length - 1 && (
            <IconSymbol name="chevron.right" size={18} color={canProceed ? "#FFFFFF" : colors.muted} />
          )}
        </Pressable>
      </View>
    </ScreenContainer>
  );
}

function getNPSColor(score: number): string {
  if (score >= 9) return "#10B981";
  if (score >= 7) return "#F59E0B";
  return "#EF4444";
}

const styles = StyleSheet.create({
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  thankYou: { flex: 1, alignItems: "center", justifyContent: "center", gap: 16, padding: 32 },
  thankEmoji: { fontSize: 64 },
  thankTitle: { fontSize: 28, fontWeight: "800" },
  thankSub: { fontSize: 16, textAlign: "center", lineHeight: 24 },
  doneBtn: { paddingHorizontal: 32, paddingVertical: 14, borderRadius: 20, marginTop: 8 },
  doneBtnText: { color: "#FFFFFF", fontSize: 16, fontWeight: "700" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
    gap: 12,
  },
  backBtn: { padding: 4 },
  surveyTitle: { fontSize: 15, fontWeight: "700" },
  progress: { fontSize: 12, marginTop: 2 },
  progressTrack: { height: 3 },
  progressFill: { height: "100%", borderRadius: 2 },
  content: { padding: 24, gap: 24 },
  questionText: { fontSize: 20, fontWeight: "700", lineHeight: 28 },
  npsContainer: { gap: 12 },
  npsScale: { flexDirection: "row", flexWrap: "wrap", gap: 8, justifyContent: "center" },
  npsBtn: {
    width: 48,
    height: 48,
    borderRadius: 12,
    borderWidth: 1.5,
    alignItems: "center",
    justifyContent: "center",
  },
  npsNum: { fontSize: 16, fontWeight: "700" },
  npsLabels: { flexDirection: "row", justifyContent: "space-between" },
  npsLabelText: { fontSize: 11 },
  starContainer: { alignItems: "center", gap: 12 },
  starLabel: { fontSize: 16, fontWeight: "600" },
  choiceList: { gap: 10 },
  choiceItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 12,
    borderWidth: 1.5,
    gap: 12,
  },
  choiceRadio: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  choiceRadioDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#FFFFFF" },
  choiceText: { fontSize: 15 },
  textArea: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 14,
    fontSize: 15,
    minHeight: 120,
    lineHeight: 22,
  },
  footer: {
    flexDirection: "row",
    padding: 16,
    gap: 10,
    borderTopWidth: 0.5,
  },
  prevBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 1,
  },
  prevText: { fontSize: 15, fontWeight: "600" },
  nextBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 14,
    minWidth: 140,
  },
  nextText: { fontSize: 15, fontWeight: "700" },
});
