import {
  View, Text, ScrollView, Pressable, StyleSheet, Image, FlatList
} from "react-native";
import { useState } from "react";
import { useLocalSearchParams, router } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { StarRating } from "@/components/ui/star-rating";
import { FeedbackCard } from "@/components/ui/feedback-card";
import { useColors } from "@/hooks/use-colors";
import { MOCK_PRODUCTS, MOCK_FEEDBACKS, DEFAULT_TAGS } from "@/lib/data";
import { openWebOrder, openLineChat } from "@/lib/line-order";

export default function ProductDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const [selectedFlavor, setSelectedFlavor] = useState<string | null>(null);
  const product = MOCK_PRODUCTS.find((p) => p.id === id);

  if (!product) {
    return (
      <ScreenContainer>
        <View style={styles.loading}>
          <Text style={{ color: colors.muted }}>ไม่พบสินค้า</Text>
        </View>
      </ScreenContainer>
    );
  }

  const productFeedbacks = MOCK_FEEDBACKS.filter((f) => f.productId === product.id);

  const handleWebOrder = () => {
    openWebOrder(product.productUrl);
  };

  const handleLineChat = () => {
    const msg = selectedFlavor
      ? `สวัสดีครับ/ค่ะ 👋 สอบถามเรื่อง ${product.name} กลิ่น ${selectedFlavor} ครับ/ค่ะ`
      : `สวัสดีครับ/ค่า 👋 สอบถามเรื่อง ${product.name} ครับ/ค่า`;
    openLineChat(msg);
  };

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="chevron.left" size={24} color={colors.primary} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]} numberOfLines={1}>
          {product.name}
        </Text>
        <View style={{ width: 32 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
        {/* Product Image */}
        <View style={styles.imageContainer}>
          <Image source={{ uri: product.imageUrl }} style={styles.productImage} resizeMode="cover" />
          {product.puffs && (
            <View style={[styles.puffsBadge, { backgroundColor: colors.primary }]}>
              <Text style={styles.puffsBadgeText}>
                {product.puffs >= 1000 ? `${(product.puffs / 1000).toFixed(0)}K` : product.puffs} Puffs
              </Text>
            </View>
          )}
        </View>

        {/* Product Info */}
        <View style={styles.infoSection}>
          {/* Brand */}
          {product.brand && (
            <View style={[styles.brandBadge, { backgroundColor: colors.primary + "15" }]}>
              <Text style={[styles.brandText, { color: colors.primary }]}>{product.brand}</Text>
            </View>
          )}

          <View style={styles.nameRow}>
            <Text style={[styles.productName, { color: colors.foreground }]}>{product.name}</Text>
            {!product.inStock && (
              <View style={[styles.stockBadge, { backgroundColor: colors.error + "20" }]}>
                <Text style={[styles.stockText, { color: colors.error }]}>สินค้าหมด</Text>
              </View>
            )}
          </View>

          <View style={styles.ratingRow}>
            <StarRating value={product.rating} size={20} readonly />
            <Text style={[styles.ratingNum, { color: colors.foreground }]}>{product.rating}</Text>
            <Text style={[styles.reviewCount, { color: colors.muted }]}>({product.reviewCount} รีวิว)</Text>
          </View>

          {/* ราคาซ่อนในหน้าแคตตาล็อก — แสดงเฉพาะที่เว็บ */}

          <Text style={[styles.description, { color: colors.foreground }]}>
            {product.description}
          </Text>
        </View>

        {/* Flavors — Selectable */}
        {product.flavors && product.flavors.length > 0 && (
          <View style={[styles.flavorsSection, { borderTopColor: colors.border }]}>
            <View style={styles.flavorHeader}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                เลือกกลิ่น ({product.flavors.length} กลิ่น)
              </Text>
              {selectedFlavor && (
                <Pressable onPress={() => setSelectedFlavor(null)}>
                  <Text style={{ color: colors.muted, fontSize: 12 }}>ล้าง</Text>
                </Pressable>
              )}
            </View>
            <View style={styles.flavorGrid}>
              {product.flavors.map((flavor, i) => (
                <Pressable
                  key={i}
                  onPress={() => setSelectedFlavor(flavor === selectedFlavor ? null : flavor)}
                  style={[
                    styles.flavorChip,
                    flavor === selectedFlavor
                      ? { backgroundColor: "#06C755", borderColor: "#06C755" }
                      : { backgroundColor: colors.surface, borderColor: colors.border },
                  ]}
                >
                  <Text style={[
                    styles.flavorText,
                    { color: flavor === selectedFlavor ? "#FFFFFF" : colors.foreground },
                  ]}>
                    {flavor}
                  </Text>
                </Pressable>
              ))}
            </View>
            {selectedFlavor && (
              <View style={[styles.selectedFlavorBanner, { backgroundColor: colors.primary + "15", borderColor: colors.primary }]}>
                <Text style={{ color: colors.primary, fontSize: 13, fontWeight: "700" }}>
                  ✅ เลือก: {selectedFlavor} · กดปุ่มสั่งซื้อหน้าเว็บเพื่อสั่งซื้อ
                </Text>
              </View>
            )}
          </View>
        )}

        {/* Action Buttons */}
        <View style={styles.ctaSection}>
          {/* Web Order — Primary CTA */}
          <Pressable
            onPress={handleWebOrder}
            style={({ pressed }) => [
              styles.webOrderBtn,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.88 },
            ]}
          >
            <Text style={styles.webOrderIcon}>🌐</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.webOrderBtnText}>สั่งซื้อหน้าเว็บ marbohub.com</Text>
              <Text style={styles.webOrderBtnSub}>
                {selectedFlavor ? `กลิ่น: ${selectedFlavor}` : "สินค้าครบ · ชำระง่าย · ส่งด่วน"}
              </Text>
            </View>
            <IconSymbol name="chevron.right" size={18} color="#FFFFFF" />
          </Pressable>

          {/* LINE Chat — Secondary */}
          <Pressable
            onPress={handleLineChat}
            style={({ pressed }) => [styles.lineChatBtn, pressed && { opacity: 0.85 }]}
          >
            <Text style={styles.lineChatIcon}>💬</Text>
            <Text style={styles.lineChatBtnText}>LINE ติดต่อสอบถามข้อมูลเพิ่มเติม</Text>
          </Pressable>

          {/* Leave Review */}
          <Pressable
            onPress={() => router.push({ pathname: "/survey/fill/[id]" as any, params: { id: "s2" } })}
            style={[styles.reviewBtn, { borderColor: colors.primary }]}
          >
            <IconSymbol name="star.fill" size={18} color={colors.primary} />
            <Text style={[styles.reviewBtnText, { color: colors.primary }]}>รีวิวสินค้านี้</Text>
          </Pressable>
        </View>

        {/* MarboHub Info Banner */}
        <View style={[styles.infoBanner, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.infoRow}>
            <Text style={{ fontSize: 16 }}>⏰</Text>
            <Text style={[styles.infoText, { color: colors.foreground }]}><Text style={{ fontWeight: "800", color: "#FF6B00" }}>รับออเดอร์ 24 ชั่วโมง</Text> · ทุกวัน ไม่มีวันหยุด</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={{ fontSize: 16 }}>⚡</Text>
            <Text style={[styles.infoText, { color: colors.foreground }]}><Text style={{ fontWeight: "800", color: colors.primary }}>จัดส่งด่วน</Text> · ภายใน 1-3 ชั่วโมงหลังสั่งซื้อ</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={{ fontSize: 16 }}>💵</Text>
            <Text style={[styles.infoText, { color: colors.foreground }]}><Text style={{ fontWeight: "800", color: "#10B981" }}>เก็บเงินปลายทาง (COD)</Text> · จ่ายเมื่อได้รับสินค้า</Text>
          </View>
          <View style={styles.infoRow}>
            <IconSymbol name="checkmark.seal.fill" size={16} color={colors.success} />
            <Text style={[styles.infoText, { color: colors.foreground }]}>สินค้าของแท้ 100% · ไม่ระบุตัวตน</Text>
          </View>
        </View>

        {/* Customer Reviews */}
        {productFeedbacks.length > 0 && (
          <View style={styles.reviewsSection}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              รีวิวจากลูกค้า ({productFeedbacks.length})
            </Text>
            {productFeedbacks.map((fb) => (
              <FeedbackCard
                key={fb.id}
                item={fb}
                tags={DEFAULT_TAGS}
                onPress={() => router.push({ pathname: "/feedback/[id]" as any, params: { id: fb.id } })}
              />
            ))}
          </View>
        )}

        {productFeedbacks.length === 0 && (
          <View style={styles.noReviews}>
            <Text style={styles.noReviewsEmoji}>✍️</Text>
            <Text style={[styles.noReviewsText, { color: colors.muted }]}>
              เป็นคนแรกที่รีวิวสินค้านี้!
            </Text>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
    gap: 8,
  },
  backBtn: { padding: 4 },
  headerTitle: { flex: 1, fontSize: 16, fontWeight: "700", textAlign: "center" },
  imageContainer: { position: "relative" },
  productImage: { width: "100%", height: 280 },
  puffsBadge: {
    position: "absolute",
    bottom: 12,
    left: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  puffsBadgeText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
  infoSection: { padding: 20, gap: 12 },
  brandBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  brandText: { fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.5 },
  nameRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  productName: { flex: 1, fontSize: 20, fontWeight: "700", lineHeight: 28 },
  stockBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  stockText: { fontSize: 11, fontWeight: "600" },
  ratingRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  ratingNum: { fontSize: 16, fontWeight: "700" },
  reviewCount: { fontSize: 14 },
  price: { fontSize: 28, fontWeight: "800", letterSpacing: -0.5 },
  description: { fontSize: 15, lineHeight: 24 },
  flavorsSection: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderTopWidth: 0.5,
    gap: 12,
  },
  flavorHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  flavorGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  flavorChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
  },
  flavorText: { fontSize: 12, fontWeight: "500" },
  selectedFlavorBanner: {
    padding: 10,
    borderRadius: 10,
    borderWidth: 1,
  },
  ctaSection: { paddingHorizontal: 20, paddingVertical: 16, gap: 10 },
  webOrderBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 18,
    borderRadius: 18,
  },
  webOrderIcon: { fontSize: 26 },
  webOrderBtnText: { color: "#FFFFFF", fontSize: 17, fontWeight: "800" },
  webOrderBtnSub: { color: "rgba(255,255,255,0.85)", fontSize: 12, marginTop: 2 },
  lineChatBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 14,
    borderRadius: 16,
    backgroundColor: "#06C755",
  },
  lineChatIcon: { fontSize: 20 },
  lineChatBtnText: { color: "#FFFFFF", fontSize: 15, fontWeight: "700" },
  reviewBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1.5,
  },
  reviewBtnText: { fontSize: 15, fontWeight: "600" },
  infoBanner: {
    marginHorizontal: 20,
    marginBottom: 8,
    padding: 16,
    borderRadius: 14,
    borderWidth: 1,
    gap: 10,
  },
  infoRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  infoText: { fontSize: 13, lineHeight: 18 },
  reviewsSection: { padding: 16, gap: 8 },
  sectionTitle: { fontSize: 16, fontWeight: "700", marginBottom: 4 },
  noReviews: { alignItems: "center", padding: 32, gap: 8 },
  noReviewsEmoji: { fontSize: 40 },
  noReviewsText: { fontSize: 15 },
});
