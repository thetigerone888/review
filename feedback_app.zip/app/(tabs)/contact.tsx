import {
  View, Text, ScrollView, Pressable, StyleSheet, TextInput, Alert, Linking
} from "react-native";
import { useState } from "react";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { CONTACT_CHANNELS, BUSINESS_HOURS } from "@/lib/data";
import type { ContactChannel } from "@/lib/types";

const CHANNEL_ICON_MAP: Record<string, string> = {
  phone: "phone.fill",
  email: "envelope.fill",
  line: "message.fill",
  facebook: "person.2.fill",
  website: "globe",
  instagram: "camera.fill",
};

const CHANNEL_COLOR_MAP: Record<string, string> = {
  phone: "#10B981",
  email: "#4F46E5",
  line: "#00C300",
  facebook: "#1877F2",
  website: "#6B7280",
  instagram: "#E1306C",
};

export default function ContactScreen() {
  const colors = useColors();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  const handleContact = (channel: ContactChannel) => {
    switch (channel.type) {
      case "phone":
        Linking.openURL(`tel:${channel.value.replace(/-/g, "")}`);
        break;
      case "email":
        Linking.openURL(`mailto:${channel.value}`);
        break;
      case "website":
        Linking.openURL(`https://${channel.value}`);
        break;
      case "line":
        Linking.openURL(channel.value);
        break;
      case "facebook":
        Linking.openURL(`https://www.facebook.com/${channel.value}`);
        break;
      default:
        Alert.alert(channel.label, `${channel.value}\n\nแตะเพื่อเปิดแอป ${channel.label}`, [
          { text: "ตกลง" },
        ]);
    }
  };

  const handleSendMessage = async () => {
    if (!name.trim() || !email.trim() || !message.trim()) {
      Alert.alert("กรุณากรอกข้อมูลให้ครบ");
      return;
    }
    setSending(true);
    await new Promise((r) => setTimeout(r, 1500));
    setSending(false);
    Alert.alert("ส่งสำเร็จ!", "เราได้รับข้อความของคุณแล้ว จะติดต่อกลับภายใน 24 ชั่วโมง", [
      {
        text: "ตกลง",
        onPress: () => {
          setName("");
          setEmail("");
          setMessage("");
        },
      },
    ]);
  };

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
        {/* Header */}
        <View style={[styles.header, { backgroundColor: colors.primary }]}>
          <Text style={styles.headerTitle}>ติดต่อ MarboHub</Text>
          <Text style={styles.headerSub}>รับออเดอร์ 24 ชั่วโมง · จัดส่งด่วน · เก็บปลายทางได้</Text>
        </View>

        {/* Company Info */}
        <View style={[styles.companyCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={[styles.companyLogo, { backgroundColor: `${colors.primary}15` }]}>
            <Text style={styles.companyLogoText}>MH</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.companyName, { color: colors.foreground }]}>MarboHub</Text>
            <Text style={[styles.companyTagline, { color: colors.muted }]}>
              ร้านพอตไฟฟ้าออนไลน์ · รับออเดอร์ 24 ชั่วโมง
            </Text>
          </View>
        </View>

        {/* Service Highlights Banner */}
        <View style={[styles.serviceHighlight, { backgroundColor: "#FF6B00" + "12", borderColor: "#FF6B00" + "40" }]}>
          <View style={styles.serviceRow}>
            <View style={[styles.serviceIconBox, { backgroundColor: "#FF6B00" }]}>
              <Text style={styles.serviceIconText}>⏰</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.serviceTitle, { color: colors.foreground }]}>รับออเดอร์ 24 ชั่วโมง</Text>
              <Text style={[styles.serviceSub, { color: colors.muted }]}>สั่งได้ตลอด ทุกวัน ไม่มีวันหยุด</Text>
            </View>
          </View>
          <View style={[styles.serviceDivider, { backgroundColor: "#FF6B00" + "20" }]} />
          <View style={styles.serviceRow}>
            <View style={[styles.serviceIconBox, { backgroundColor: "#4F46E5" }]}>
              <Text style={styles.serviceIconText}>⚡</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.serviceTitle, { color: colors.foreground }]}>จัดส่งด่วน ภายใน 1-3 ชั่วโมง</Text>
              <Text style={[styles.serviceSub, { color: colors.muted }]}>ส่งทั่วไทย ตามรอบชั่วโมง ในเขตกรุงเทพฯส่งไวยิ่งขึ้น</Text>
            </View>
          </View>
          <View style={[styles.serviceDivider, { backgroundColor: "#FF6B00" + "20" }]} />
          <View style={styles.serviceRow}>
            <View style={[styles.serviceIconBox, { backgroundColor: "#10B981" }]}>
              <Text style={styles.serviceIconText}>💵</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.serviceTitle, { color: colors.foreground }]}>เก็บเงินปลายทาง (COD)</Text>
              <Text style={[styles.serviceSub, { color: colors.muted }]}>จ่ายเมื่อได้รับสินค้า ไม่ต้องโอนล่วงหน้า</Text>
            </View>
          </View>
        </View>

        {/* Contact Channels */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>ช่องทางติดต่อ</Text>
          <View style={[styles.channelsList, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {CONTACT_CHANNELS.map((channel, index) => {
              const channelColor = CHANNEL_COLOR_MAP[channel.type] ?? colors.primary;
              const iconName = CHANNEL_ICON_MAP[channel.type] ?? "globe";
              return (
                <View key={channel.id}>
                  <Pressable
                    onPress={() => handleContact(channel)}
                    style={({ pressed }) => [styles.channelItem, pressed && { backgroundColor: `${colors.primary}08` }]}
                  >
                    <View style={[styles.channelIcon, { backgroundColor: `${channelColor}15` }]}>
                      <IconSymbol name={iconName as any} size={20} color={channelColor} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.channelLabel, { color: colors.foreground }]}>{channel.label}</Text>
                      <Text style={[styles.channelValue, { color: colors.muted }]}>{channel.value}</Text>
                    </View>
                    <IconSymbol name="chevron.right" size={16} color={colors.muted} />
                  </Pressable>
                  {index < CONTACT_CHANNELS.length - 1 && (
                    <View style={[styles.divider, { backgroundColor: colors.border }]} />
                  )}
                </View>
              );
            })}
          </View>
        </View>

        {/* Business Hours */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>เวลาทำการ</Text>
          <View style={[styles.hoursCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.hoursHeader}>
              <IconSymbol name="clock.fill" size={16} color={colors.primary} />
              <Text style={[styles.hoursTitle, { color: colors.foreground }]}>ตารางเวลา</Text>
            </View>
            {BUSINESS_HOURS.map((h, i) => (
              <View key={i} style={styles.hoursRow}>
                <Text style={[styles.hoursDay, { color: colors.foreground }]}>{h.day}</Text>
                <Text style={[styles.hoursTime, { color: h.closed ? colors.error : colors.success }]}>
                  {h.closed ? "ปิดทำการ" : `${h.open} - ${h.close} น.`}
                </Text>
              </View>
            ))}
          </View>
        </View>


        {/* Contact Form */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>ส่งข้อความถึงเรา</Text>
          <View style={[styles.formCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View>
              <Text style={[styles.inputLabel, { color: colors.foreground }]}>ชื่อ-นามสกุล *</Text>
              <TextInput
                style={[styles.input, { backgroundColor: colors.background, borderColor: colors.border, color: colors.foreground }]}
                placeholder="ชื่อของคุณ"
                placeholderTextColor={colors.muted}
                value={name}
                onChangeText={setName}
                returnKeyType="next"
              />
            </View>
            <View>
              <Text style={[styles.inputLabel, { color: colors.foreground }]}>อีเมล *</Text>
              <TextInput
                style={[styles.input, { backgroundColor: colors.background, borderColor: colors.border, color: colors.foreground }]}
                placeholder="your@email.com"
                placeholderTextColor={colors.muted}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                returnKeyType="next"
              />
            </View>
            <View>
              <Text style={[styles.inputLabel, { color: colors.foreground }]}>ข้อความ *</Text>
              <TextInput
                style={[styles.textArea, { backgroundColor: colors.background, borderColor: colors.border, color: colors.foreground }]}
                placeholder="พิมพ์ข้อความของคุณที่นี่..."
                placeholderTextColor={colors.muted}
                value={message}
                onChangeText={setMessage}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
              />
            </View>
            <Pressable
              onPress={handleSendMessage}
              style={({ pressed }) => [
                styles.sendBtn,
                { backgroundColor: sending ? colors.muted : colors.primary },
                pressed && { opacity: 0.85 },
              ]}
              disabled={sending}
            >
              <IconSymbol name="paperplane.fill" size={18} color="#FFFFFF" />
              <Text style={styles.sendBtnText}>
                {sending ? "กำลังส่ง..." : "ส่งข้อความ"}
              </Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 24,
  },
  headerTitle: { fontSize: 22, fontWeight: "700", color: "#FFFFFF" },
  headerSub: { fontSize: 13, color: "rgba(255,255,255,0.75)", marginTop: 2 },
  companyCard: {
    flexDirection: "row",
    alignItems: "center",
    margin: 16,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 14,
  },
  companyLogo: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  companyLogoText: { fontSize: 20, fontWeight: "800", color: "#4F46E5", letterSpacing: 0.5 },
  companyName: { fontSize: 16, fontWeight: "700" },
  companyTagline: { fontSize: 13, marginTop: 2 },
  section: { paddingHorizontal: 16, marginBottom: 8 },
  sectionTitle: { fontSize: 16, fontWeight: "700", marginBottom: 10 },
  channelsList: {
    borderRadius: 16,
    borderWidth: 1,
    overflow: "hidden",
  },
  channelItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    gap: 12,
  },
  channelIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  channelLabel: { fontSize: 14, fontWeight: "600" },
  channelValue: { fontSize: 13, marginTop: 1 },
  divider: { height: 0.5, marginLeft: 66 },
  hoursCard: {
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 10,
  },
  hoursHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 4 },
  hoursTitle: { fontSize: 14, fontWeight: "700" },
  hoursRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  hoursDay: { fontSize: 14 },
  hoursTime: { fontSize: 14, fontWeight: "600" },
  formCard: {
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 14,
  },
  inputLabel: { fontSize: 13, fontWeight: "600", marginBottom: 6 },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  textArea: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    minHeight: 100,
  },
  sendBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 14,
    borderRadius: 12,
  },
  sendBtnText: { color: "#FFFFFF", fontSize: 15, fontWeight: "700" },
  serviceHighlight: {
    marginHorizontal: 16,
    marginBottom: 8,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 12,
  },
  serviceRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  serviceIconBox: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  serviceIconText: { fontSize: 20 },
  serviceTitle: { fontSize: 14, fontWeight: "700", lineHeight: 20 },
  serviceSub: { fontSize: 12, marginTop: 2, lineHeight: 17 },
  serviceDivider: { height: 1, borderRadius: 1 },
});
