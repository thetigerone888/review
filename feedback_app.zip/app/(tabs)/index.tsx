import { ScrollView, Text, View, RefreshControl, Pressable, StyleSheet } from "react-native";
import { useState, useEffect, useCallback } from "react";
import { router } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { KPICard } from "@/components/ui/kpi-card";
import { FeedbackCard } from "@/components/ui/feedback-card";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import {
  loadFeedbacks,
  loadTags,
  computeStats,
  computeNPSTrend,
} from "@/lib/data";
import type { FeedbackItem, FeedbackTag, DashboardStats } from "@/lib/types";

export default function DashboardScreen() {
  const colors = useColors();
  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>([]);
  const [tags, setTags] = useState<FeedbackTag[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalResponses: 0, npsScore: 0, avgRating: 0, responseRate: 0,
    positiveCount: 0, neutralCount: 0, negativeCount: 0,
  });
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    const [fb, tg] = await Promise.all([loadFeedbacks(), loadTags()]);
    setFeedbacks(fb);
    setTags(tg);
    setStats(computeStats(fb));
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }, [loadData]);

  const recentFeedbacks = feedbacks.filter((f) => !f.isArchived).slice(0, 5);
  const trend = computeNPSTrend();
  const maxTrend = Math.max(...trend.map((t) => t.score), 1);

  return (
    <ScreenContainer>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
        contentContainerStyle={{ paddingBottom: 24 }}
      >
        {/* Header */}
        <View style={[styles.header, { backgroundColor: colors.primary }]}>
          <View>
            <Text style={styles.headerTitle}>FeedbackPro</Text>
            <Text style={styles.headerSub}>แดชบอร์ดภาพรวม</Text>
          </View>
          <Pressable
            onPress={() => router.push("/analytics" as any)}
            style={({ pressed }) => [styles.analyticsBtn, pressed && { opacity: 0.7 }]}
          >
            <IconSymbol name="chart.bar.fill" size={20} color="#FFFFFF" />
          </Pressable>
        </View>

        <View style={styles.content}>
          {/* KPI Cards */}
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>ตัวชี้วัดหลัก</Text>
          <View style={styles.kpiGrid}>
            <View style={styles.kpiRow}>
              <KPICard
                title="ความคิดเห็นทั้งหมด"
                value={stats.totalResponses}
                icon="bubble.left.and.bubble.right.fill"
                iconColor={colors.primary}
                trend={12}
                onPress={() => router.push("/(tabs)/feedback" as any)}
              />
              <KPICard
                title="คะแนน NPS"
                value={stats.npsScore}
                icon="chart.line.uptrend.xyaxis"
                iconColor="#8B5CF6"
                trend={5}
              />
            </View>
            <View style={styles.kpiRow}>
              <KPICard
                title="คะแนนเฉลี่ย"
                value={`${stats.avgRating} ★`}
                icon="star.fill"
                iconColor="#F59E0B"
                trend={3}
              />
              <KPICard
                title="อัตราตอบกลับ"
                value={`${stats.responseRate}%`}
                icon="person.2.fill"
                iconColor="#10B981"
                trend={-2}
              />
            </View>
          </View>

          {/* Sentiment Overview */}
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>ภาพรวมความรู้สึก</Text>
          <View style={[styles.sentimentCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <SentimentBar
              label="เชิงบวก"
              count={stats.positiveCount}
              total={stats.totalResponses}
              color={colors.success}
              emoji="😊"
            />
            <SentimentBar
              label="กลาง"
              count={stats.neutralCount}
              total={stats.totalResponses}
              color={colors.warning}
              emoji="😐"
            />
            <SentimentBar
              label="เชิงลบ"
              count={stats.negativeCount}
              total={stats.totalResponses}
              color={colors.error}
              emoji="😞"
            />
          </View>

          {/* NPS Trend */}
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>แนวโน้ม NPS (7 วัน)</Text>
          <View style={[styles.trendCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.trendChart}>
              {trend.map((point, i) => (
                <View key={i} style={styles.trendBar}>
                  <View
                    style={[
                      styles.trendBarFill,
                      {
                        height: `${(point.score / maxTrend) * 100}%`,
                        backgroundColor: colors.primary,
                        opacity: i === trend.length - 1 ? 1 : 0.5,
                      },
                    ]}
                  />
                  <Text style={[styles.trendLabel, { color: colors.muted }]}>{point.date.split(" ")[0]}</Text>
                </View>
              ))}
            </View>
            <View style={styles.trendFooter}>
              <Text style={[styles.trendScore, { color: colors.primary }]}>
                NPS ล่าสุด: {trend[trend.length - 1]?.score ?? 0}
              </Text>
            </View>
          </View>

          {/* Recent Feedback */}
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>ความคิดเห็นล่าสุด</Text>
            <Pressable onPress={() => router.push("/(tabs)/feedback" as any)}>
              <Text style={[styles.seeAll, { color: colors.primary }]}>ดูทั้งหมด</Text>
            </Pressable>
          </View>
          {recentFeedbacks.map((item) => (
            <FeedbackCard
              key={item.id}
              item={item}
              tags={tags}
              onPress={() => router.push({ pathname: "/feedback/[id]" as any, params: { id: item.id } })}
            />
          ))}

          {/* Quick Action */}
          <Pressable
            onPress={() => router.push("/(tabs)/survey" as any)}
            style={({ pressed }) => [
              styles.quickAction,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.85 },
            ]}
          >
            <IconSymbol name="plus.circle.fill" size={20} color="#FFFFFF" />
            <Text style={styles.quickActionText}>สร้างแบบสอบถามใหม่</Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function SentimentBar({ label, count, total, color, emoji }: {
  label: string; count: number; total: number; color: string; emoji: string;
}) {
  const colors = useColors();
  const pct = total > 0 ? (count / total) * 100 : 0;
  return (
    <View style={styles.sentimentRow}>
      <Text style={styles.sentimentEmoji}>{emoji}</Text>
      <Text style={[styles.sentimentLabel, { color: colors.foreground }]}>{label}</Text>
      <View style={[styles.sentimentTrack, { backgroundColor: colors.border }]}>
        <View style={[styles.sentimentFill, { width: `${pct}%`, backgroundColor: color }]} />
      </View>
      <Text style={[styles.sentimentCount, { color: colors.muted }]}>{count}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 24,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  headerSub: {
    fontSize: 13,
    color: "rgba(255,255,255,0.75)",
    marginTop: 2,
  },
  analyticsBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(255,255,255,0.2)",
    alignItems: "center",
    justifyContent: "center",
  },
  content: {
    padding: 16,
    gap: 4,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    marginTop: 12,
    marginBottom: 8,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 12,
    marginBottom: 8,
  },
  seeAll: {
    fontSize: 14,
    fontWeight: "600",
  },
  kpiGrid: {
    gap: 10,
  },
  kpiRow: {
    flexDirection: "row",
    gap: 10,
  },
  sentimentCard: {
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 12,
  },
  sentimentRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  sentimentEmoji: {
    fontSize: 16,
    width: 24,
  },
  sentimentLabel: {
    fontSize: 13,
    fontWeight: "500",
    width: 64,
  },
  sentimentTrack: {
    flex: 1,
    height: 8,
    borderRadius: 4,
    overflow: "hidden",
  },
  sentimentFill: {
    height: "100%",
    borderRadius: 4,
  },
  sentimentCount: {
    fontSize: 13,
    fontWeight: "600",
    width: 24,
    textAlign: "right",
  },
  trendCard: {
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
  },
  trendChart: {
    flexDirection: "row",
    alignItems: "flex-end",
    height: 80,
    gap: 6,
  },
  trendBar: {
    flex: 1,
    alignItems: "center",
    height: "100%",
    justifyContent: "flex-end",
    gap: 4,
  },
  trendBarFill: {
    width: "100%",
    borderRadius: 4,
    minHeight: 4,
  },
  trendLabel: {
    fontSize: 9,
  },
  trendFooter: {
    marginTop: 8,
    alignItems: "center",
  },
  trendScore: {
    fontSize: 13,
    fontWeight: "600",
  },
  quickAction: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 16,
    borderRadius: 16,
    marginTop: 8,
  },
  quickActionText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
  },
});
