import {
  View, Text, FlatList, TextInput, Pressable, StyleSheet, Alert
} from "react-native";
import { useState, useEffect, useCallback } from "react";
import { router } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { FeedbackCard } from "@/components/ui/feedback-card";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { loadFeedbacks, loadTags, saveFeedbacks, exportFeedbacksToCSV } from "@/lib/data";
import type { FeedbackItem, FeedbackTag, SentimentType } from "@/lib/types";

type FilterType = "all" | SentimentType | "tagged";

const FILTERS: { key: FilterType; label: string }[] = [
  { key: "all", label: "ทั้งหมด" },
  { key: "positive", label: "😊 บวก" },
  { key: "neutral", label: "😐 กลาง" },
  { key: "negative", label: "😞 ลบ" },
  { key: "tagged", label: "🏷 มีแท็ก" },
];

type SortType = "latest" | "oldest" | "rating_high" | "rating_low";

export default function FeedbackScreen() {
  const colors = useColors();
  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>([]);
  const [tags, setTags] = useState<FeedbackTag[]>([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FilterType>("all");
  const [sort, setSort] = useState<SortType>("latest");
  const [showSort, setShowSort] = useState(false);

  const loadData = useCallback(async () => {
    const [fb, tg] = await Promise.all([loadFeedbacks(), loadTags()]);
    setFeedbacks(fb);
    setTags(tg);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const filtered = feedbacks
    .filter((f) => !f.isArchived)
    .filter((f) => {
      if (filter === "tagged") return f.tags.length > 0;
      if (filter !== "all") return f.sentiment === filter;
      return true;
    })
    .filter((f) => {
      if (!search) return true;
      return (
        f.customerName.toLowerCase().includes(search.toLowerCase()) ||
        f.comment.toLowerCase().includes(search.toLowerCase())
      );
    })
    .sort((a, b) => {
      if (sort === "latest") return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sort === "oldest") return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      if (sort === "rating_high") return b.rating - a.rating;
      return a.rating - b.rating;
    });

  const handleExport = () => {
    const csv = exportFeedbacksToCSV(filtered, tags);
    Alert.alert(
      "ส่งออกข้อมูล",
      `พร้อมส่งออก ${filtered.length} รายการ\n\nในอุปกรณ์จริงจะบันทึกไฟล์ CSV ลงเครื่อง`,
      [{ text: "ตกลง" }]
    );
  };

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Text style={[styles.title, { color: colors.foreground }]}>ความคิดเห็น</Text>
        <View style={styles.headerActions}>
          <Pressable
            onPress={() => setShowSort(!showSort)}
            style={({ pressed }) => [styles.iconBtn, { backgroundColor: colors.border }, pressed && { opacity: 0.7 }]}
          >
            <IconSymbol name="arrow.up.arrow.down" size={18} color={colors.foreground} />
          </Pressable>
          <Pressable
            onPress={handleExport}
            style={({ pressed }) => [styles.iconBtn, { backgroundColor: colors.primary }, pressed && { opacity: 0.7 }]}
          >
            <IconSymbol name="square.and.arrow.up" size={18} color="#FFFFFF" />
          </Pressable>
        </View>
      </View>

      {/* Sort Dropdown */}
      {showSort && (
        <View style={[styles.sortMenu, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {[
            { key: "latest", label: "ล่าสุดก่อน" },
            { key: "oldest", label: "เก่าสุดก่อน" },
            { key: "rating_high", label: "คะแนนสูงสุด" },
            { key: "rating_low", label: "คะแนนต่ำสุด" },
          ].map((s) => (
            <Pressable
              key={s.key}
              onPress={() => { setSort(s.key as SortType); setShowSort(false); }}
              style={[styles.sortItem, sort === s.key && { backgroundColor: `${colors.primary}15` }]}
            >
              <Text style={[styles.sortLabel, { color: sort === s.key ? colors.primary : colors.foreground }]}>
                {s.label}
              </Text>
              {sort === s.key && <IconSymbol name="checkmark" size={16} color={colors.primary} />}
            </Pressable>
          ))}
        </View>
      )}

      {/* Search */}
      <View style={[styles.searchBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <IconSymbol name="magnifyingglass" size={18} color={colors.muted} />
        <TextInput
          style={[styles.searchInput, { color: colors.foreground }]}
          placeholder="ค้นหาความคิดเห็น..."
          placeholderTextColor={colors.muted}
          value={search}
          onChangeText={setSearch}
          returnKeyType="search"
        />
        {search.length > 0 && (
          <Pressable onPress={() => setSearch("")}>
            <IconSymbol name="xmark.circle.fill" size={18} color={colors.muted} />
          </Pressable>
        )}
      </View>

      {/* Filter Chips */}
      <FlatList
        horizontal
        data={FILTERS}
        keyExtractor={(item) => item.key}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filterList}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => setFilter(item.key)}
            style={[
              styles.filterChip,
              filter === item.key
                ? { backgroundColor: colors.primary }
                : { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 },
            ]}
          >
            <Text style={[styles.filterLabel, { color: filter === item.key ? "#FFFFFF" : colors.foreground }]}>
              {item.label}
            </Text>
          </Pressable>
        )}
      />

      {/* Count */}
      <Text style={[styles.countText, { color: colors.muted }]}>
        {filtered.length} รายการ
      </Text>

      {/* List */}
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <FeedbackCard
            item={item}
            tags={tags}
            onPress={() => router.push({ pathname: "/feedback/[id]" as any, params: { id: item.id } })}
          />
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyEmoji}>💬</Text>
            <Text style={[styles.emptyText, { color: colors.muted }]}>ไม่พบความคิดเห็น</Text>
          </View>
        }
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 0.5,
  },
  title: {
    fontSize: 20,
    fontWeight: "700",
  },
  headerActions: {
    flexDirection: "row",
    gap: 8,
  },
  iconBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  sortMenu: {
    position: "absolute",
    top: 64,
    right: 16,
    zIndex: 100,
    borderRadius: 12,
    borderWidth: 1,
    overflow: "hidden",
    minWidth: 160,
  },
  sortItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  sortLabel: {
    fontSize: 14,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    marginHorizontal: 16,
    marginTop: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
  },
  filterList: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
  },
  filterLabel: {
    fontSize: 13,
    fontWeight: "600",
  },
  countText: {
    fontSize: 12,
    paddingHorizontal: 16,
    marginBottom: 4,
  },
  list: {
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  empty: {
    alignItems: "center",
    paddingTop: 60,
    gap: 8,
  },
  emptyEmoji: {
    fontSize: 40,
  },
  emptyText: {
    fontSize: 16,
  },
});
