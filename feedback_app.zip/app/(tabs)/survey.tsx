import {
  View, Text, FlatList, Pressable, StyleSheet, Modal, TextInput, ScrollView, Alert
} from "react-native";
import { useState, useEffect, useCallback } from "react";
import { router } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { loadSurveys, saveSurveys } from "@/lib/data";
import type { Survey, SurveyQuestion, QuestionType } from "@/lib/types";

const STATUS_CONFIG = {
  active: { label: "เปิดใช้งาน", color: "#10B981", bg: "#D1FAE5" },
  closed: { label: "ปิดแล้ว", color: "#6B7280", bg: "#F3F4F6" },
  draft: { label: "ร่าง", color: "#F59E0B", bg: "#FEF3C7" },
};

const QUESTION_TYPES: { type: QuestionType; label: string; icon: string }[] = [
  { type: "nps", label: "NPS (0-10)", icon: "chart.line.uptrend.xyaxis" },
  { type: "star", label: "ดาว (1-5)", icon: "star.fill" },
  { type: "multiple_choice", label: "หลายตัวเลือก", icon: "checkmark.circle.fill" },
  { type: "open_text", label: "ข้อความเปิด", icon: "doc.text.fill" },
];

export default function SurveyScreen() {
  const colors = useColors();
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [questions, setQuestions] = useState<SurveyQuestion[]>([
    { id: "q1", type: "nps", text: "คุณจะแนะนำเราให้ผู้อื่นมากน้อยแค่ไหน?", required: true },
    { id: "q2", type: "star", text: "คุณพอใจกับสินค้า/บริการของเรามากน้อยแค่ไหน?", required: true },
    { id: "q3", type: "open_text", text: "มีข้อเสนอแนะอะไรเพิ่มเติมไหม?", required: false },
  ]);

  const loadData = useCallback(async () => {
    const sv = await loadSurveys();
    setSurveys(sv);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const createSurvey = async () => {
    if (!newTitle.trim()) {
      Alert.alert("กรุณาใส่ชื่อแบบสอบถาม");
      return;
    }
    const newSurvey: Survey = {
      id: `s${Date.now()}`,
      title: newTitle.trim(),
      description: newDesc.trim() || undefined,
      questions,
      status: "active",
      channels: ["survey", "qr"],
      responseCount: 0,
      createdAt: new Date().toISOString(),
    };
    const updated = [newSurvey, ...surveys];
    setSurveys(updated);
    await saveSurveys(updated);
    setShowCreate(false);
    setNewTitle("");
    setNewDesc("");
    Alert.alert("สำเร็จ", "สร้างแบบสอบถามเรียบร้อยแล้ว");
  };

  const toggleStatus = async (survey: Survey) => {
    const updated = surveys.map((s) =>
      s.id === survey.id
        ? { ...s, status: s.status === "active" ? "closed" as const : "active" as const }
        : s
    );
    setSurveys(updated);
    await saveSurveys(updated);
  };

  const shareOptions = (survey: Survey) => {
    Alert.alert(
      "แชร์แบบสอบถาม",
      `"${survey.title}"`,
      [
        { text: "คัดลอกลิงก์", onPress: () => Alert.alert("คัดลอกแล้ว", "https://feedbackpro.th/s/" + survey.id) },
        { text: "แสดง QR Code", onPress: () => Alert.alert("QR Code", "ในอุปกรณ์จริงจะแสดง QR Code สำหรับแบบสอบถาม") },
        { text: "ยกเลิก", style: "cancel" },
      ]
    );
  };

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Text style={[styles.title, { color: colors.foreground }]}>แบบสอบถาม</Text>
        <Pressable
          onPress={() => setShowCreate(true)}
          style={[styles.createBtn, { backgroundColor: colors.primary }]}
        >
          <IconSymbol name="plus" size={16} color="#FFFFFF" />
          <Text style={styles.createBtnText}>สร้างใหม่</Text>
        </Pressable>
      </View>

      {/* Survey List */}
      <FlatList
        data={surveys}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const statusCfg = STATUS_CONFIG[item.status];
          return (
            <View style={[styles.surveyCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={styles.surveyHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.surveyTitle, { color: colors.foreground }]}>{item.title}</Text>
                  {item.description && (
                    <Text style={[styles.surveyDesc, { color: colors.muted }]} numberOfLines={1}>
                      {item.description}
                    </Text>
                  )}
                </View>
                <View style={[styles.statusBadge, { backgroundColor: statusCfg.bg }]}>
                  <Text style={[styles.statusText, { color: statusCfg.color }]}>{statusCfg.label}</Text>
                </View>
              </View>

              <View style={styles.surveyStats}>
                <View style={styles.statItem}>
                  <IconSymbol name="bubble.left.and.bubble.right.fill" size={14} color={colors.muted} />
                  <Text style={[styles.statText, { color: colors.muted }]}>{item.responseCount} ตอบ</Text>
                </View>
                <View style={styles.statItem}>
                  <IconSymbol name="doc.text.fill" size={14} color={colors.muted} />
                  <Text style={[styles.statText, { color: colors.muted }]}>{item.questions.length} คำถาม</Text>
                </View>
                <View style={styles.statItem}>
                  <IconSymbol name="qrcode" size={14} color={colors.muted} />
                  <Text style={[styles.statText, { color: colors.muted }]}>{item.channels.length} ช่องทาง</Text>
                </View>
              </View>

              <View style={styles.surveyActions}>
                <Pressable
                  onPress={() => router.push({ pathname: "/survey/fill/[id]" as any, params: { id: item.id } })}
                  style={[styles.actionBtn, { backgroundColor: `${colors.primary}15` }]}
                >
                  <IconSymbol name="pencil" size={14} color={colors.primary} />
                  <Text style={[styles.actionText, { color: colors.primary }]}>ดูตัวอย่าง</Text>
                </Pressable>
                <Pressable
                  onPress={() => shareOptions(item)}
                  style={[styles.actionBtn, { backgroundColor: `${colors.success}15` }]}
                >
                  <IconSymbol name="square.and.arrow.up" size={14} color={colors.success} />
                  <Text style={[styles.actionText, { color: colors.success }]}>แชร์</Text>
                </Pressable>
                <Pressable
                  onPress={() => toggleStatus(item)}
                  style={[styles.actionBtn, { backgroundColor: `${colors.muted}20` }]}
                >
                  <IconSymbol name={item.status === "active" ? "xmark" : "checkmark"} size={14} color={colors.muted} />
                  <Text style={[styles.actionText, { color: colors.muted }]}>
                    {item.status === "active" ? "ปิด" : "เปิด"}
                  </Text>
                </Pressable>
              </View>
            </View>
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyEmoji}>📋</Text>
            <Text style={[styles.emptyText, { color: colors.muted }]}>ยังไม่มีแบบสอบถาม</Text>
            <Pressable
              onPress={() => setShowCreate(true)}
              style={[styles.emptyBtn, { backgroundColor: colors.primary }]}
            >
              <Text style={styles.emptyBtnText}>สร้างแบบสอบถามแรก</Text>
            </Pressable>
          </View>
        }
      />

      {/* Create Survey Modal */}
      <Modal visible={showCreate} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.surface }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>สร้างแบบสอบถาม</Text>
              <Pressable onPress={() => setShowCreate(false)}>
                <IconSymbol name="xmark.circle.fill" size={24} color={colors.muted} />
              </Pressable>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              <View style={{ gap: 12 }}>
                <View>
                  <Text style={[styles.inputLabel, { color: colors.foreground }]}>ชื่อแบบสอบถาม *</Text>
                  <TextInput
                    style={[styles.input, { backgroundColor: colors.background, borderColor: colors.border, color: colors.foreground }]}
                    placeholder="เช่น แบบสอบถามความพึงพอใจ"
                    placeholderTextColor={colors.muted}
                    value={newTitle}
                    onChangeText={setNewTitle}
                    returnKeyType="next"
                  />
                </View>
                <View>
                  <Text style={[styles.inputLabel, { color: colors.foreground }]}>คำอธิบาย</Text>
                  <TextInput
                    style={[styles.input, styles.textArea, { backgroundColor: colors.background, borderColor: colors.border, color: colors.foreground }]}
                    placeholder="อธิบายวัตถุประสงค์ของแบบสอบถาม"
                    placeholderTextColor={colors.muted}
                    value={newDesc}
                    onChangeText={setNewDesc}
                    multiline
                    numberOfLines={3}
                  />
                </View>
                <View>
                  <Text style={[styles.inputLabel, { color: colors.foreground }]}>คำถาม ({questions.length})</Text>
                  {questions.map((q, i) => {
                    const qType = QUESTION_TYPES.find((t) => t.type === q.type);
                    return (
                      <View key={q.id} style={[styles.questionItem, { backgroundColor: colors.background, borderColor: colors.border }]}>
                        <View style={styles.questionHeader}>
                          <IconSymbol name={qType?.icon as any} size={14} color={colors.primary} />
                          <Text style={[styles.questionType, { color: colors.primary }]}>{qType?.label}</Text>
                          {!q.required && <Text style={[styles.optional, { color: colors.muted }]}>ไม่บังคับ</Text>}
                        </View>
                        <Text style={[styles.questionText, { color: colors.foreground }]}>{q.text}</Text>
                      </View>
                    );
                  })}
                </View>
                <Pressable
                  onPress={createSurvey}
                  style={[styles.createConfirmBtn, { backgroundColor: colors.primary }]}
                >
                  <Text style={styles.createConfirmText}>สร้างแบบสอบถาม</Text>
                </Pressable>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 0.5,
  },
  title: { fontSize: 20, fontWeight: "700" },
  createBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
  },
  createBtnText: { color: "#FFFFFF", fontSize: 14, fontWeight: "600" },
  list: { padding: 16, gap: 12 },
  surveyCard: {
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 12,
  },
  surveyHeader: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  surveyTitle: { fontSize: 15, fontWeight: "700" },
  surveyDesc: { fontSize: 13, marginTop: 2 },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  statusText: { fontSize: 11, fontWeight: "600" },
  surveyStats: { flexDirection: "row", gap: 16 },
  statItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  statText: { fontSize: 12 },
  surveyActions: { flexDirection: "row", gap: 8 },
  actionBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
    paddingVertical: 8,
    borderRadius: 10,
  },
  actionText: { fontSize: 12, fontWeight: "600" },
  empty: { alignItems: "center", paddingTop: 80, gap: 12 },
  emptyEmoji: { fontSize: 48 },
  emptyText: { fontSize: 16 },
  emptyBtn: { paddingHorizontal: 24, paddingVertical: 12, borderRadius: 20, marginTop: 8 },
  emptyBtnText: { color: "#FFFFFF", fontSize: 15, fontWeight: "600" },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" },
  modalContent: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: "90%", gap: 16 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  modalTitle: { fontSize: 18, fontWeight: "700" },
  inputLabel: { fontSize: 13, fontWeight: "600", marginBottom: 6 },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  textArea: { height: 80, textAlignVertical: "top" },
  questionItem: {
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
    marginBottom: 8,
    gap: 4,
  },
  questionHeader: { flexDirection: "row", alignItems: "center", gap: 6 },
  questionType: { fontSize: 11, fontWeight: "600" },
  optional: { fontSize: 11, marginLeft: "auto" },
  questionText: { fontSize: 13 },
  createConfirmBtn: { padding: 16, borderRadius: 14, alignItems: "center", marginTop: 8 },
  createConfirmText: { color: "#FFFFFF", fontSize: 16, fontWeight: "700" },
});
