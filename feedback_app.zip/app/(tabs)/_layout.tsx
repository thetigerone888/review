import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Platform, View } from "react-native";

import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { LineFloatingButton } from "@/components/ui/line-floating-button";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 60 + bottomPadding;

  return (
    <View style={{ flex: 1 }}>
      <Tabs
        screenOptions={{
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: colors.muted,
          headerShown: false,
          tabBarButton: HapticTab,
          tabBarLabelStyle: {
            fontSize: 10,
            fontWeight: "600",
            marginTop: -2,
          },
          tabBarStyle: {
            paddingTop: 8,
            paddingBottom: bottomPadding,
            height: tabBarHeight,
            backgroundColor: colors.surface,
            borderTopColor: colors.border,
            borderTopWidth: 0.5,
          },
        }}
      >
        {/* Tab 1: หน้าแรก = ความรู้ + หลักฐานส่ง + รีวิวรูป */}
        <Tabs.Screen
          name="knowledge"
          options={{
            title: "หน้าแรก",
            tabBarIcon: ({ color }) => <IconSymbol size={24} name="house.fill" color={color} />,
          }}
        />
        {/* Tab 2: แคตตาล็อกสินค้า */}
        <Tabs.Screen
          name="catalog"
          options={{
            title: "สินค้า",
            tabBarIcon: ({ color }) => <IconSymbol size={24} name="cart.fill" color={color} />,
          }}
        />
        {/* Tab 3: ความคิดเห็น */}
        <Tabs.Screen
          name="feedback"
          options={{
            title: "รีวิว",
            tabBarIcon: ({ color }) => <IconSymbol size={24} name="bubble.left.and.bubble.right.fill" color={color} />,
          }}
        />
        {/* Tab 4: แดชบอร์ด */}
        <Tabs.Screen
          name="index"
          options={{
            title: "แดชบอร์ด",
            tabBarIcon: ({ color }) => <IconSymbol size={24} name="chart.bar.fill" color={color} />,
          }}
        />
        {/* Tab 5: ติดต่อ */}
        <Tabs.Screen
          name="contact"
          options={{
            title: "ติดต่อ",
            tabBarIcon: ({ color }) => <IconSymbol size={24} name="phone.fill" color={color} />,
          }}
        />
        {/* Hidden tabs (accessible via push navigation) */}
        <Tabs.Screen
          name="survey"
          options={{
            href: null,
            title: "แบบสอบถาม",
          }}
        />
      </Tabs>
      <LineFloatingButton />
    </View>
  );
}
