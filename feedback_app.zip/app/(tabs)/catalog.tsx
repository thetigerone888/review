import {
  View, Text, FlatList, TextInput, Pressable, StyleSheet, Image
} from "react-native";
import { useState } from "react";
import { router } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { MOCK_PRODUCTS, PRODUCT_CATEGORIES } from "@/lib/data";
import { openWebOrder, openLineChat } from "@/lib/line-order";
import type { Product } from "@/lib/types";

export default function CatalogScreen() {
  const colors = useColors();
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filtered = MOCK_PRODUCTS.filter((p) => {
    const matchCat = selectedCategory === "all" || p.categoryId === selectedCategory;
    const matchSearch = !search || p.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const featured = MOCK_PRODUCTS.filter((p) => p.rating >= 4.7).slice(0, 3);

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.primary }]}>
        <View style={styles.headerTop}>
          <View>
            <Text style={[styles.headerTitle]}>📖 แคตตาล็อกสินค้า</Text>           <Text style={styles.headerSub}>รับออเดอร์ 24 ชั่วโมง · จัดส่งด่วน · เก็บปลายทาง</Text>
          </View>
          {/* LINE Quick Contact */}
          <Pressable
            onPress={() => openLineChat("สวัสดีครับ/ค่ะ 👋 ต้องการสอบถามสินค้าครับ/ค่ะ")}
            style={({ pressed }) => [styles.lineHeaderBtn, pressed && { opacity: 0.8 }]}
          >
            <Text style={styles.lineHeaderBtnText}>💬 ทักแชท</Text>
          </Pressable>
        </View>

        {/* Website Banner */}
        <Pressable
          onPress={() => openWebOrder()}
          style={({ pressed }) => [styles.webBanner, pressed && { opacity: 0.85 }]}
        >
          <Text style={styles.webBannerIcon}>🌐</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.webBannerTitle}>สั่งซื้อที่เว็บไซต์ marbohub.com</Text>
            <Text style={styles.webBannerSub}>สินค้าครบ · เก็บปลายทางได้ · ส่งด่วน 24 ชม.</Text>
          </View>
          <IconSymbol name="chevron.right" size={16} color="rgba(255,255,255,0.8)" />
        </Pressable>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        numColumns={2}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.grid}
        columnWrapperStyle={{ gap: 12 }}
        ListHeaderComponent={
          <View style={{ gap: 12 }}>
            {/* COD Hero Banner */}
            <View style={[styles.codHero, { backgroundColor: colors.primary }]}>
              <View style={styles.codHeroTop}>
                <Text style={styles.codHeroIcon}>💵</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.codHeroTitle}>เก็บเงินปลายทาง (COD)</Text>
                  <Text style={styles.codHeroSub}>สั่งได้เลย ไม่ต้องโอนก่อน!</Text>
                </View>
                <View style={styles.codBadge}>
                  <Text style={styles.codBadgeText}>ฟรี!</Text>
                </View>
              </View>
              <View style={styles.codPoints}>
                <View style={styles.codPoint}>
                  <Text style={styles.codPointIcon}>✅</Text>
                  <Text style={styles.codPointText}>ไม่ต้องโอนเงินล่วงหน้า</Text>
                </View>
                <View style={styles.codPoint}>
                  <Text style={styles.codPointIcon}>📦</Text>
                  <Text style={styles.codPointText}>จ่ายเมื่อรับของ 100%</Text>
                </View>
                <View style={styles.codPoint}>
                  <Text style={styles.codPointIcon}>🛡️</Text>
                  <Text style={styles.codPointText}>ไม่ได้ของ ไม่ต้องจ่าย</Text>
                </View>
                <View style={styles.codPoint}>
                  <Text style={styles.codPointIcon}>⚡</Text>
                  <Text style={styles.codPointText}>ส่งด่วนถึงมือคุณ</Text>
                </View>
              </View>
            </View>

            {/* Search */}
            <View style={[styles.searchBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <IconSymbol name="magnifyingglass" size={18} color={colors.muted} />
              <TextInput
                style={[styles.searchInput, { color: colors.foreground }]}
                placeholder="ค้นหาสินค้า..."
                placeholderTextColor={colors.muted}
                value={search}
                onChangeText={setSearch}
                returnKeyType="search"
              />
              {search.length > 0 && (
                <Pressable onPress={() => setSearch("")}>
                  <IconSymbol name="xmark.circle.fill" size={18} color={colors.muted} />
                </Pressable>
              )}
            </View>

            {/* Category Filter */}
            <FlatList
              horizontal
              data={PRODUCT_CATEGORIES}
              keyExtractor={(item) => item.id}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ gap: 8 }}
              renderItem={({ item }) => (
                <Pressable
                  onPress={() => setSelectedCategory(item.id)}
                  style={[
                    styles.catChip,
                    selectedCategory === item.id
                      ? { backgroundColor: colors.primary }
                      : { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 },
                  ]}
                >
                  <Text style={[styles.catText, { color: selectedCategory === item.id ? "#FFFFFF" : colors.foreground }]}>
                    {item.name}
                  </Text>
                </Pressable>
              )}
            />

            {/* Featured */}
            {selectedCategory === "all" && !search && (
              <View>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>⭐ แนะนำ</Text>
                <FlatList
                  horizontal
                  data={featured}
                  keyExtractor={(item) => item.id}
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={{ gap: 12 }}
                  renderItem={({ item }) => (
                    <FeaturedCard
                      item={item}
                      onPress={() => router.push({ pathname: "/product/[id]" as any, params: { id: item.id } })}
                      onWebOrder={() => openWebOrder(item.productUrl)}
                    />
                  )}
                />
              </View>
            )}

            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              {selectedCategory === "all" ? "สินค้าทั้งหมด" : PRODUCT_CATEGORIES.find((c) => c.id === selectedCategory)?.name}
              <Text style={[styles.countBadge, { color: colors.muted }]}> ({filtered.length})</Text>
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <ProductCard
            item={item}
            onPress={() => router.push({ pathname: "/product/[id]" as any, params: { id: item.id } })}
            onWebOrder={() => openWebOrder(item.productUrl)}
          />
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyEmoji}>🛍️</Text>
            <Text style={[styles.emptyText, { color: colors.muted }]}>ไม่พบสินค้า</Text>
          </View>
        }
      />
    </ScreenContainer>
  );
}

function ProductCard({
  item,
  onPress,
  onWebOrder,
}: {
  item: Product;
  onPress: () => void;
  onWebOrder: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.productCard,
        { backgroundColor: colors.surface, borderColor: colors.border },
        pressed && { opacity: 0.85 },
      ]}
    >
      <View style={styles.productImageContainer}>
        <Image source={{ uri: item.imageUrl }} style={styles.productImage} resizeMode="cover" />
        {item.puffs && (
          <View style={[styles.puffsBadge, { backgroundColor: colors.primary }]}>
            <Text style={styles.puffsBadgeText}>
              {item.puffs >= 1000 ? `${(item.puffs / 1000).toFixed(0)}K` : item.puffs} Puffs
            </Text>
          </View>
        )}
        {!item.inStock && (
          <View style={styles.outOfStock}>
            <Text style={styles.outOfStockText}>หมด</Text>
          </View>
        )}
      </View>
        <View style={styles.productInfo}>
          {item.brand && (
            <Text style={[styles.brandLabel, { color: colors.muted }]}>{item.brand}</Text>
          )}
          <Text style={[styles.productName, { color: colors.foreground }]} numberOfLines={2}>
            {item.name}
          </Text>
          <View style={styles.productRating}>
            <IconSymbol name="star.fill" size={12} color="#F59E0B" />
            <Text style={[styles.ratingText, { color: colors.muted }]}>
              {item.rating} ({item.reviewCount})
            </Text>
          </View>
          {/* ซ่อนราคา — เป็นหน้าแคตตาล็อก */}
          {/* ปุ่มดูรายละเอียด */}
          <Pressable
            onPress={(e) => { e.stopPropagation?.(); onPress(); }}
            style={({ pressed }) => [
              styles.webOrderBtn,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.85 },
            ]}
          >
            <Text style={styles.webOrderBtnText}>📖 ดูรายละเอียด</Text>
          </Pressable>
        </View>
    </Pressable>
  );
}

function FeaturedCard({
  item,
  onPress,
  onWebOrder,
}: {
  item: Product;
  onPress: () => void;
  onWebOrder: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.featuredCard,
        { backgroundColor: colors.surface, borderColor: colors.border },
        pressed && { opacity: 0.85 },
      ]}
    >
      <Image source={{ uri: item.imageUrl }} style={styles.featuredImage} resizeMode="cover" />
      <View style={styles.featuredInfo}>
        <Text style={[styles.featuredName, { color: colors.foreground }]} numberOfLines={1}>
          {item.name}
        </Text>
        {item.brand && (
          <Text style={[styles.featuredBrand, { color: colors.muted }]}>{item.brand}</Text>
        )}
        <View style={styles.featuredBottom}>
          <View style={styles.featuredRating}>
            <IconSymbol name="star.fill" size={11} color="#F59E0B" />
            <Text style={[styles.featuredRatingText, { color: colors.muted }]}>{item.rating}</Text>
          </View>
          <Pressable
            onPress={(e) => { e.stopPropagation?.(); onPress(); }}
            style={({ pressed }) => [styles.featuredWebBtn, { backgroundColor: colors.primary }, pressed && { opacity: 0.8 }]}
          >
            <Text style={styles.featuredWebBtnText}>ดูเพิ่มเติม</Text>
          </Pressable>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 12,
    gap: 10,
  },
  headerTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  headerTitle: { fontSize: 20, fontWeight: "700", color: "#FFFFFF" },
  headerSub: { fontSize: 12, color: "rgba(255,255,255,0.75)", marginTop: 2 },
  lineHeaderBtn: {
    backgroundColor: "rgba(255,255,255,0.2)",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.4)",
  },
  lineHeaderBtnText: { color: "#FFFFFF", fontSize: 13, fontWeight: "700" },
  webBanner: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.15)",
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    gap: 10,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.25)",
  },
  webBannerIcon: { fontSize: 20 },
  webBannerTitle: { color: "#FFFFFF", fontSize: 13, fontWeight: "700" },
  webBannerSub: { color: "rgba(255,255,255,0.8)", fontSize: 11, marginTop: 1 },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    gap: 8,
  },
  searchInput: { flex: 1, fontSize: 14 },
  catChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20 },
  catText: { fontSize: 13, fontWeight: "600" },
  sectionTitle: { fontSize: 16, fontWeight: "700", marginTop: 4 },
  countBadge: { fontSize: 14, fontWeight: "400" },
  grid: { padding: 16, gap: 12 },
  productCard: {
    flex: 1,
    borderRadius: 14,
    borderWidth: 1,
    overflow: "hidden",
  },
  productImageContainer: { position: "relative" },
  productImage: { width: "100%", height: 130 },
  outOfStock: {
    position: "absolute",
    top: 8,
    right: 8,
    backgroundColor: "rgba(0,0,0,0.6)",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  outOfStockText: { color: "#FFFFFF", fontSize: 10, fontWeight: "600" },
  productInfo: { padding: 10, gap: 3 },
  brandLabel: { fontSize: 10, fontWeight: "600", textTransform: "uppercase", letterSpacing: 0.5 },
  productName: { fontSize: 13, fontWeight: "600", lineHeight: 18 },
  puffsBadge: {
    position: "absolute",
    bottom: 6,
    left: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  puffsBadgeText: { color: "#FFFFFF", fontSize: 10, fontWeight: "700" },
  productRating: { flexDirection: "row", alignItems: "center", gap: 3 },
  ratingText: { fontSize: 11 },
  priceRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  productPrice: { fontSize: 15, fontWeight: "700", marginTop: 2 },
  webOrderBtn: {
    marginTop: 6,
    paddingVertical: 7,
    borderRadius: 10,
    alignItems: "center",
  },
  webOrderBtnText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
  featuredCard: {
    width: 160,
    borderRadius: 14,
    borderWidth: 1,
    overflow: "hidden",
  },
  featuredImage: { width: "100%", height: 110 },
  featuredInfo: { padding: 10, gap: 4 },
  featuredName: { fontSize: 13, fontWeight: "600" },
  featuredBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  featuredBrand: { fontSize: 10, fontWeight: "600", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 4 },
  featuredRating: { flexDirection: "row", alignItems: "center", gap: 3 },
  featuredRatingText: { fontSize: 12, fontWeight: "600" },
  featuredWebBtn: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  featuredWebBtnText: { color: "#FFFFFF", fontSize: 11, fontWeight: "700" },
  empty: { alignItems: "center", paddingTop: 60, gap: 8 },
  emptyEmoji: { fontSize: 40 },
  emptyText: { fontSize: 16 },
  codHero: {
    borderRadius: 16,
    padding: 16,
    gap: 12,
  },
  codHeroTop: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  codHeroIcon: { fontSize: 28 },
  codHeroTitle: { fontSize: 17, fontWeight: "800", color: "#FFFFFF" },
  codHeroSub: { fontSize: 12, color: "rgba(255,255,255,0.85)", marginTop: 2 },
  codBadge: {
    backgroundColor: "#FFD700",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
  },
  codBadgeText: { color: "#000", fontSize: 13, fontWeight: "800" },
  codPoints: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  codPoint: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: "rgba(255,255,255,0.18)",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 20,
  },
  codPointIcon: { fontSize: 13 },
  codPointText: { color: "#FFFFFF", fontSize: 12, fontWeight: "600" },
});
