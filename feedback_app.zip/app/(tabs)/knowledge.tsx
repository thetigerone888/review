import {
  View, Text, FlatList, Pressable, StyleSheet, TextInput,
  ScrollView, Image, Alert, ActivityIndicator
} from "react-native";
import { useState, useCallback, useMemo } from "react";
import { router } from "expo-router";
import * as ImagePicker from "expo-image-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import {
  KNOWLEDGE_ARTICLES,
  KNOWLEDGE_CATEGORIES,
  type KnowledgeArticle,
} from "@/lib/knowledge-data";
import {
  DELIVERY_RECORDS,
  DELIVERY_STATS,
  getStatusLabel,
  getStatusColor,
  formatOrderDate,
  type DeliveryItem,
} from "@/lib/delivery-data";
import { openLineChat } from "@/lib/line-order";

// ============================================================
// Types
// ============================================================
interface PhotoReview {
  id: string;
  imageUri: string;
  rating: number;
  comment: string;
  productName: string;
  createdAt: string;
}

const PHOTO_REVIEW_KEY = "marbohub_photo_reviews";

// ============================================================
// Main Screen
// ============================================================
export default function KnowledgeScreen() {
  const colors = useColors();
  const [activeSection, setActiveSection] = useState<"knowledge" | "delivery" | "review">("knowledge");

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.primary }]}>
        <Text style={styles.headerBrand}>MarboHub</Text>
        <Text style={styles.headerTagline}>รับออเดอร์ 24 ชม. · จัดส่งด่วน · เก็บปลายทางได้</Text>

        {/* Section Tabs */}
        <View style={styles.sectionTabs}>
          {[
            { key: "knowledge", label: "📚 ความรู้", icon: "book.fill" },
            { key: "delivery", label: "🚚 หลักฐานส่ง", icon: "truck.box.fill" },
            { key: "review", label: "📸 รีวิวรูป", icon: "camera.fill" },
          ].map((tab) => (
            <Pressable
              key={tab.key}
              onPress={() => setActiveSection(tab.key as any)}
              style={[
                styles.sectionTab,
                activeSection === tab.key
                  ? { backgroundColor: "#FFFFFF" }
                  : { backgroundColor: "rgba(255,255,255,0.15)" },
              ]}
            >
              <Text
                style={[
                  styles.sectionTabText,
                  { color: activeSection === tab.key ? colors.primary : "#FFFFFF" },
                ]}
              >
                {tab.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* Content */}
      {activeSection === "knowledge" && <KnowledgeSection />}
      {activeSection === "delivery" && <DeliverySection />}
      {activeSection === "review" && <PhotoReviewSection />}
    </ScreenContainer>
  );
}

type SortOption = "latest" | "popular" | "readtime";

// ============================================================
// Knowledge Section
// ============================================================
function KnowledgeSection() {
  const colors = useColors();
  const [search, setSearch] = useState("");
  const [selectedCat, setSelectedCat] = useState("all");
  const [sortBy, setSortBy] = useState<SortOption>("latest");
  const [showSort, setShowSort] = useState(false);

  const SORT_OPTIONS: { key: SortOption; label: string }[] = [
    { key: "latest", label: "ล่าสุด" },
    { key: "popular", label: "ยอดนิยม" },
    { key: "readtime", label: "อ่านเร็ว" },
  ];

  const filtered = useMemo(() => {
    let result = KNOWLEDGE_ARTICLES.filter((a) => {
      const matchCat = selectedCat === "all" || a.categoryId === selectedCat;
      const matchSearch =
        !search ||
        a.title.toLowerCase().includes(search.toLowerCase()) ||
        a.summary.toLowerCase().includes(search.toLowerCase()) ||
        a.tags.some((t) => t.toLowerCase().includes(search.toLowerCase()));
      return matchCat && matchSearch;
    });
    if (sortBy === "popular") result = [...result].sort((a, b) => b.readMinutes - a.readMinutes);
    else if (sortBy === "readtime") result = [...result].sort((a, b) => a.readMinutes - b.readMinutes);
    return result;
  }, [search, selectedCat, sortBy]);

  const featured = KNOWLEDGE_ARTICLES.filter((a) => a.isFeatured);
  const hasFilter = search.length > 0 || selectedCat !== "all";

  const clearAll = () => {
    setSearch("");
    setSelectedCat("all");
  };

  return (
    <FlatList
      data={filtered}
      keyExtractor={(item) => item.id}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={
        <View style={{ gap: 12 }}>
          {/* Search + Sort Row */}
          <View style={{ flexDirection: "row", gap: 8, alignItems: "center" }}>
            <View style={[styles.searchBar, { flex: 1, backgroundColor: colors.surface, borderColor: colors.border }]}>
              <IconSymbol name="magnifyingglass" size={18} color={colors.muted} />
              <TextInput
                style={[styles.searchInput, { color: colors.foreground }]}
                placeholder="ค้นหาบทความ, แท็ก..."
                placeholderTextColor={colors.muted}
                value={search}
                onChangeText={setSearch}
                returnKeyType="search"
              />
              {search.length > 0 && (
                <Pressable onPress={() => setSearch("")}>
                  <IconSymbol name="xmark.circle.fill" size={18} color={colors.muted} />
                </Pressable>
              )}
            </View>
            {/* Sort Button */}
            <Pressable
              onPress={() => setShowSort(!showSort)}
              style={({ pressed }) => [
                styles.sortBtn,
                { backgroundColor: showSort ? colors.primary : colors.surface, borderColor: colors.border },
                pressed && { opacity: 0.8 },
              ]}
            >
              <IconSymbol name="arrow.up.arrow.down" size={16} color={showSort ? "#FFFFFF" : colors.foreground} />
            </Pressable>
          </View>

          {/* Sort Dropdown */}
          {showSort && (
            <View style={[styles.sortDropdown, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              {SORT_OPTIONS.map((opt) => (
                <Pressable
                  key={opt.key}
                  onPress={() => { setSortBy(opt.key); setShowSort(false); }}
                  style={({ pressed }) => [
                    styles.sortOption,
                    sortBy === opt.key && { backgroundColor: colors.primary + "18" },
                    pressed && { opacity: 0.8 },
                  ]}
                >
                  <Text style={[styles.sortOptionText, { color: sortBy === opt.key ? colors.primary : colors.foreground, fontWeight: sortBy === opt.key ? "700" : "400" }]}>
                    {sortBy === opt.key ? "✓ " : "   "}{opt.label}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}

          {/* Category Filter */}
          <FlatList
            horizontal
            data={KNOWLEDGE_CATEGORIES}
            keyExtractor={(item) => item.id}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 8 }}
            renderItem={({ item }) => (
              <Pressable
                onPress={() => setSelectedCat(item.id)}
                style={[
                  styles.catChip,
                  selectedCat === item.id
                    ? { backgroundColor: colors.primary }
                    : { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 },
                ]}
              >
                <Text style={[styles.catText, { color: selectedCat === item.id ? "#FFFFFF" : colors.foreground }]}>
                  {item.name}
                </Text>
              </Pressable>
            )}
          />

          {/* Active Filters + Result Count */}
          <View style={styles.filterStatusRow}>
            <Text style={[styles.resultCount, { color: colors.muted }]}>
              {hasFilter ? `พบ ${filtered.length} บทความ` : `บทความทั้งหมด ${filtered.length} บทความ`}
              {sortBy !== "latest" && (
                <Text style={{ color: colors.primary }}>
                  {" · "}{SORT_OPTIONS.find((o) => o.key === sortBy)?.label}
                </Text>
              )}
            </Text>
            {hasFilter && (
              <Pressable onPress={clearAll} style={({ pressed }) => [styles.clearBtn, { backgroundColor: colors.error + "15" }, pressed && { opacity: 0.8 }]}>
                <IconSymbol name="xmark.circle.fill" size={12} color={colors.error} />
                <Text style={[styles.clearBtnText, { color: colors.error }]}>ล้างทั้งหมด</Text>
              </Pressable>
            )}
          </View>

          {/* Featured */}
          {selectedCat === "all" && !search && (
            <View style={{ gap: 8 }}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>⭐ บทความแนะนำ</Text>
              <FlatList
                horizontal
                data={featured}
                keyExtractor={(item) => item.id}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{ gap: 12 }}
                renderItem={({ item }) => (
                  <FeaturedCard
                    item={item}
                    onPress={() => router.push({ pathname: "/knowledge/[id]" as any, params: { id: item.id } })}
                  />
                )}
              />
            </View>
          )}

          {/* LINE CTA Banner */}
          {!search && selectedCat === "all" && (
            <Pressable
              onPress={() => openLineChat("สวัสดีครับ/ค่ะ 👋 ต้องการสอบถามหรือสั่งซื้อสินค้าครับ/ค่ะ")}
              style={({ pressed }) => [
                styles.lineCTABanner,
                pressed && { opacity: 0.88 },
              ]}
            >
              <Text style={styles.lineCTAIcon}>💬</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.lineCTATitle}>สอบถามหรือสั่งซื้อผ่าน LINE</Text>
                <Text style={styles.lineCTASub}>@marbohub · ตอบไว · รับออเดอร์ 24 ชม.</Text>
              </View>
              <IconSymbol name="chevron.right" size={16} color="rgba(255,255,255,0.8)" />
            </Pressable>
          )}
        </View>
      }
      renderItem={({ item }) => (
        <ArticleCard
          item={item}
          onPress={() => router.push({ pathname: "/knowledge/[id]" as any, params: { id: item.id } })}
        />
      )}
      ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
      ListEmptyComponent={
        <View style={styles.emptyBox}>
          <Text style={styles.emptyEmoji}>📖</Text>
          <Text style={[styles.emptyText, { color: colors.muted }]}>ไม่พบบทความ</Text>
          <Text style={[styles.emptySubText, { color: colors.muted }]}>ลองเปลี่ยนคำค้นหาหรือหมวดหมู่</Text>
          <Pressable onPress={clearAll} style={[styles.clearBtn, { backgroundColor: colors.primary + "15", marginTop: 8 }]}>
            <Text style={[styles.clearBtnText, { color: colors.primary }]}>ล้างการค้นหา</Text>
          </Pressable>
        </View>
      }
    />
  );
}

// ============================================================
// Delivery Proof Section
// ============================================================
function DeliverySection() {
  const colors = useColors();

  const deliveredCount = DELIVERY_RECORDS.filter((d) => d.status === "delivered").length;

  return (
    <FlatList
      data={DELIVERY_RECORDS}
      keyExtractor={(item) => item.id}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={
        <View style={{ gap: 12 }}>
          {/* Service Badges Row */}
          <View style={styles.serviceBadgesRow}>
            <View style={[styles.serviceBadge, { backgroundColor: "#FF6B00" }]}>
              <Text style={styles.serviceBadgeIcon}>⏰</Text>
              <Text style={styles.serviceBadgeText}>รับออเดอร์{"\n"}24 ชั่วโมง</Text>
            </View>
            <View style={[styles.serviceBadge, { backgroundColor: "#4F46E5" }]}>
              <Text style={styles.serviceBadgeIcon}>⚡</Text>
              <Text style={styles.serviceBadgeText}>จัดส่ง{"\n"}ด่วน</Text>
            </View>
            <View style={[styles.serviceBadge, { backgroundColor: "#10B981" }]}>
              <Text style={styles.serviceBadgeIcon}>💵</Text>
              <Text style={styles.serviceBadgeText}>เก็บ{"\n"}ปลายทาง</Text>
            </View>
            <View style={[styles.serviceBadge, { backgroundColor: "#8B5CF6" }]}>
              <Text style={styles.serviceBadgeIcon}>📦</Text>
              <Text style={styles.serviceBadgeText}>ไม่{"\n"}ระบุตัวตน</Text>
            </View>
          </View>

          {/* Trust Banner */}
          <View style={[styles.trustBanner, { backgroundColor: "#10B981" + "12", borderColor: "#10B981" + "40" }]}>
            <View style={styles.trustRow}>
              <View style={[styles.trustIconBox, { backgroundColor: "#10B981" }]}>
                <IconSymbol name="checkmark.seal.fill" size={20} color="#FFFFFF" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.trustTitle, { color: colors.foreground }]}>หลักฐานการจัดส่งจริง</Text>
                <Text style={[styles.trustSub, { color: colors.muted }]}>
                  ข้อมูลจาก MarboHub Admin · ปิดข้อมูลส่วนตัวลูกค้า
                </Text>
              </View>
            </View>
          </View>

          {/* Stats Row */}
          <View style={styles.statsRow}>
            {[
              { label: "ออเดอร์ทั้งหมด", value: `${DELIVERY_STATS.totalOrders}+`, color: colors.primary },
              { label: "ส่งสำเร็จวันนี้", value: `${deliveredCount}/${DELIVERY_STATS.todayOrders}`, color: "#10B981" },
              { label: "อัตราสำเร็จ", value: `${DELIVERY_STATS.successRate}%`, color: "#10B981" },
              { label: "เวลาส่งเฉลี่ย", value: `~${DELIVERY_STATS.avgDeliveryMin} นาที`, color: colors.primary },
            ].map((stat, i) => (
              <View key={i} style={[styles.statCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <Text style={[styles.statValue, { color: stat.color }]}>{stat.value}</Text>
                <Text style={[styles.statLabel, { color: colors.muted }]}>{stat.label}</Text>
              </View>
            ))}
          </View>

          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            รายการจัดส่งล่าสุด
            <Text style={{ color: colors.muted, fontWeight: "400" }}> (ข้อมูลจริง)</Text>
          </Text>
        </View>
      }
      renderItem={({ item }) => <DeliveryCard item={item} />}
      ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
    />
  );
}

function DeliveryCard({ item }: { item: DeliveryItem }) {
  const colors = useColors();
  const statusColor = getStatusColor(item.status);
  const statusLabel = getStatusLabel(item.status);

  return (
    <View style={[styles.deliveryCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      {/* Header row */}
      <View style={styles.deliveryHeader}>
        <View style={styles.deliveryOrderRow}>
          <Text style={[styles.deliveryOrderCode, { color: colors.primary }]}>{item.orderCode}</Text>
          <Text style={[styles.deliveryDate, { color: colors.muted }]}>{formatOrderDate(item.orderDate)}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: statusColor + "18" }]}>
          <Text style={[styles.statusText, { color: statusColor }]}>{statusLabel}</Text>
        </View>
      </View>

      {/* Products */}
      <View style={[styles.productList, { borderTopColor: colors.border }]}>
        {item.products.map((p, i) => (
          <View key={i} style={styles.productRow}>
            <View style={[styles.productDot, { backgroundColor: colors.primary }]} />
            <Text style={[styles.productName, { color: colors.foreground }]} numberOfLines={1}>
              {p.name}
            </Text>
            <Text style={[styles.productFlavor, { color: colors.muted }]} numberOfLines={1}>
              {p.flavor}
            </Text>
          </View>
        ))}
      </View>

      {/* Footer */}
      <View style={[styles.deliveryFooter, { borderTopColor: colors.border }]}>
        <View style={styles.footerLeft}>
          {item.distanceKm && (
            <View style={styles.footerItem}>
              <IconSymbol name="clock.fill" size={12} color={colors.muted} />
              <Text style={[styles.footerText, { color: colors.muted }]}>
                {item.distanceKm} กม. · {item.durationMin} นาที
              </Text>
            </View>
          )}
          <View style={styles.footerItem}>
            <IconSymbol name="checkmark.circle.fill" size={12} color={colors.muted} />
            <Text style={[styles.footerText, { color: colors.muted }]}>
              {item.paymentMethod === "prepaid" ? "จ่ายเงินแล้ว" : "เก็บเงินปลายทาง"}
            </Text>
          </View>
        </View>
        <Text style={[styles.totalText, { color: colors.foreground }]}>฿{item.total.toLocaleString()}</Text>
      </View>
    </View>
  );
}

// ============================================================
// Photo Review Section
// ============================================================
function PhotoReviewSection() {
  const colors = useColors();
  const [reviews, setReviews] = useState<PhotoReview[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [productName, setProductName] = useState("");
  const [saving, setSaving] = useState(false);

  const loadReviews = useCallback(async () => {
    try {
      const raw = await AsyncStorage.getItem(PHOTO_REVIEW_KEY);
      if (raw) setReviews(JSON.parse(raw));
    } catch {}
  }, []);

  // Load on mount
  useState(() => { loadReviews(); });

  const pickImage = async (useCamera: boolean) => {
    const perm = useCamera
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!perm.granted) {
      Alert.alert("ไม่ได้รับสิทธิ์", "กรุณาอนุญาตการเข้าถึงกล้อง/คลัง");
      return;
    }

    const result = useCamera
      ? await ImagePicker.launchCameraAsync({ quality: 0.7, allowsEditing: true, aspect: [4, 3] })
      : await ImagePicker.launchImageLibraryAsync({ quality: 0.7, allowsEditing: true, aspect: [4, 3] });

    if (!result.canceled && result.assets[0]) {
      setSelectedImage(result.assets[0].uri);
      setShowForm(true);
    }
  };

  const saveReview = async () => {
    if (!selectedImage || !comment.trim() || !productName.trim()) {
      Alert.alert("กรุณากรอกข้อมูลให้ครบ");
      return;
    }
    setSaving(true);
    const newReview: PhotoReview = {
      id: Date.now().toString(),
      imageUri: selectedImage,
      rating,
      comment: comment.trim(),
      productName: productName.trim(),
      createdAt: new Date().toISOString(),
    };
    const updated = [newReview, ...reviews];
    await AsyncStorage.setItem(PHOTO_REVIEW_KEY, JSON.stringify(updated));
    setReviews(updated);
    setShowForm(false);
    setSelectedImage(null);
    setComment("");
    setProductName("");
    setRating(5);
    setSaving(false);
    Alert.alert("✅ บันทึกรีวิวแล้ว!", "ขอบคุณสำหรับรีวิวของคุณ");
  };

  if (showForm && selectedImage) {
    return (
      <ScrollView contentContainerStyle={[styles.listContent, { gap: 16 }]} showsVerticalScrollIndicator={false}>
        {/* Preview Image */}
        <View style={styles.imagePreviewBox}>
          <Image source={{ uri: selectedImage }} style={styles.imagePreview} resizeMode="cover" />
          <Pressable
            onPress={() => { setShowForm(false); setSelectedImage(null); }}
            style={[styles.imageRemoveBtn, { backgroundColor: colors.error ?? "#EF4444" }]}
          >
            <IconSymbol name="xmark" size={14} color="#FFFFFF" />
          </Pressable>
        </View>

        {/* Product Name */}
        <View style={{ gap: 6 }}>
          <Text style={[styles.formLabel, { color: colors.foreground }]}>ชื่อสินค้าที่รีวิว *</Text>
          <TextInput
            style={[styles.formInput, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground }]}
            placeholder="เช่น Marbo Bar 9000 กลิ่น Peach"
            placeholderTextColor={colors.muted}
            value={productName}
            onChangeText={setProductName}
            returnKeyType="next"
          />
        </View>

        {/* Star Rating */}
        <View style={{ gap: 6 }}>
          <Text style={[styles.formLabel, { color: colors.foreground }]}>คะแนน *</Text>
          <View style={styles.starRow}>
            {[1, 2, 3, 4, 5].map((s) => (
              <Pressable key={s} onPress={() => setRating(s)} style={styles.starBtn}>
                <IconSymbol
                  name={s <= rating ? "star.fill" : "star"}
                  size={36}
                  color={s <= rating ? "#F59E0B" : colors.border}
                />
              </Pressable>
            ))}
          </View>
        </View>

        {/* Comment */}
        <View style={{ gap: 6 }}>
          <Text style={[styles.formLabel, { color: colors.foreground }]}>ความคิดเห็น *</Text>
          <TextInput
            style={[
              styles.formInput,
              styles.formTextArea,
              { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground },
            ]}
            placeholder="บอกเล่าประสบการณ์การใช้งาน..."
            placeholderTextColor={colors.muted}
            value={comment}
            onChangeText={setComment}
            multiline
            numberOfLines={4}
            textAlignVertical="top"
          />
        </View>

        {/* Submit */}
        <Pressable
          onPress={saveReview}
          style={({ pressed }) => [
            styles.submitBtn,
            { backgroundColor: colors.primary },
            pressed && { opacity: 0.85 },
          ]}
        >
          {saving ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <Text style={styles.submitBtnText}>📸 บันทึกรีวิว</Text>
          )}
        </Pressable>
      </ScrollView>
    );
  }

  return (
    <FlatList
      data={reviews}
      keyExtractor={(item) => item.id}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={
        <View style={{ gap: 12 }}>
          {/* Upload Buttons */}
          <View style={[styles.uploadBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.uploadTitle, { color: colors.foreground }]}>📸 รีวิวพร้อมรูปภาพ</Text>
            <Text style={[styles.uploadSub, { color: colors.muted }]}>
              ถ่ายรูปสินค้าที่ได้รับ หรือเลือกจากคลังภาพ แล้วเขียนรีวิวได้เลย
            </Text>
            <View style={styles.uploadBtns}>
              <Pressable
                onPress={() => pickImage(true)}
                style={({ pressed }) => [
                  styles.uploadBtn,
                  { backgroundColor: colors.primary },
                  pressed && { opacity: 0.85 },
                ]}
              >
                <IconSymbol name="camera.fill" size={18} color="#FFFFFF" />
                <Text style={styles.uploadBtnText}>ถ่ายรูป</Text>
              </Pressable>
              <Pressable
                onPress={() => pickImage(false)}
                style={({ pressed }) => [
                  styles.uploadBtn,
                  { backgroundColor: colors.surface, borderColor: colors.primary, borderWidth: 1.5 },
                  pressed && { opacity: 0.85 },
                ]}
              >
                <IconSymbol name="photo.fill" size={18} color={colors.primary} />
                <Text style={[styles.uploadBtnText, { color: colors.primary }]}>เลือกรูป</Text>
              </Pressable>
            </View>
          </View>

          {reviews.length > 0 && (
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              รีวิวทั้งหมด
              <Text style={{ color: colors.muted, fontWeight: "400" }}> ({reviews.length})</Text>
            </Text>
          )}
        </View>
      }
      renderItem={({ item }) => <PhotoReviewCard item={item} />}
      ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
      ListEmptyComponent={
        <View style={styles.emptyBox}>
          <Text style={styles.emptyEmoji}>📷</Text>
          <Text style={[styles.emptyText, { color: colors.muted }]}>ยังไม่มีรีวิว</Text>
          <Text style={[styles.emptySubText, { color: colors.muted }]}>เป็นคนแรกที่รีวิวสินค้า!</Text>
        </View>
      }
    />
  );
}

function PhotoReviewCard({ item }: { item: PhotoReview }) {
  const colors = useColors();
  return (
    <View style={[styles.reviewCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <Image source={{ uri: item.imageUri }} style={styles.reviewImage} resizeMode="cover" />
      <View style={styles.reviewContent}>
        <Text style={[styles.reviewProduct, { color: colors.foreground }]} numberOfLines={1}>
          {item.productName}
        </Text>
        <View style={styles.reviewStars}>
          {[1, 2, 3, 4, 5].map((s) => (
            <IconSymbol
              key={s}
              name={s <= item.rating ? "star.fill" : "star"}
              size={14}
              color={s <= item.rating ? "#F59E0B" : colors.border}
            />
          ))}
        </View>
        <Text style={[styles.reviewComment, { color: colors.foreground }]} numberOfLines={3}>
          {item.comment}
        </Text>
        <Text style={[styles.reviewDate, { color: colors.muted }]}>
          {formatOrderDate(item.createdAt)}
        </Text>
      </View>
    </View>
  );
}

// ============================================================
// Shared Sub-components
// ============================================================
function ArticleCard({ item, onPress }: { item: KnowledgeArticle; onPress: () => void }) {
  const colors = useColors();
  const cat = KNOWLEDGE_CATEGORIES.find((c) => c.id === item.categoryId);
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.articleCard,
        { backgroundColor: colors.surface, borderColor: colors.border },
        pressed && { opacity: 0.85 },
      ]}
    >
      <View style={[styles.catBadge, { backgroundColor: (cat?.color ?? colors.primary) + "18" }]}>
        <Text style={[styles.catBadgeText, { color: cat?.color ?? colors.primary }]}>{cat?.name}</Text>
      </View>
      <Text style={[styles.articleTitle, { color: colors.foreground }]} numberOfLines={2}>{item.title}</Text>
      <Text style={[styles.articleSummary, { color: colors.muted }]} numberOfLines={2}>{item.summary}</Text>
      <View style={styles.articleFooter}>
        <View style={styles.readTimeRow}>
          <IconSymbol name="clock.fill" size={12} color={colors.muted} />
          <Text style={[styles.readTimeText, { color: colors.muted }]}>อ่าน {item.readMinutes} นาที</Text>
        </View>
        <View style={styles.tagsRow}>
          {item.tags.slice(0, 2).map((tag, i) => (
            <View key={i} style={[styles.tagPill, { backgroundColor: colors.border }]}>
              <Text style={[styles.tagPillText, { color: colors.muted }]}>{tag}</Text>
            </View>
          ))}
        </View>
      </View>
    </Pressable>
  );
}

function FeaturedCard({ item, onPress }: { item: KnowledgeArticle; onPress: () => void }) {
  const colors = useColors();
  const cat = KNOWLEDGE_CATEGORIES.find((c) => c.id === item.categoryId);
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.featuredCard,
        { backgroundColor: cat?.color ?? colors.primary },
        pressed && { opacity: 0.85 },
      ]}
    >
      <View style={[styles.featuredCatBadge, { backgroundColor: "rgba(255,255,255,0.25)" }]}>
        <Text style={styles.featuredCatText}>{cat?.name}</Text>
      </View>
      <Text style={styles.featuredTitle} numberOfLines={2}>{item.title}</Text>
      <View style={styles.featuredFooter}>
        <IconSymbol name="clock.fill" size={11} color="rgba(255,255,255,0.8)" />
        <Text style={styles.featuredTime}>{item.readMinutes} นาที</Text>
      </View>
    </Pressable>
  );
}

// ============================================================
// Styles
// ============================================================
const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
    gap: 4,
  },
  headerBrand: { fontSize: 24, fontWeight: "800", color: "#FFFFFF", letterSpacing: 0.5 },
  headerTagline: { fontSize: 12, color: "rgba(255,255,255,0.75)", marginBottom: 12 },
  sectionTabs: { flexDirection: "row", gap: 8 },
  sectionTab: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 10,
    alignItems: "center",
  },
  sectionTabText: { fontSize: 12, fontWeight: "700" },
  listContent: { padding: 16, gap: 0 },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    gap: 8,
    marginBottom: 0,
  },
  searchInput: { flex: 1, fontSize: 14 },
  catChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20 },
  catText: { fontSize: 13, fontWeight: "600" },
  sectionTitle: { fontSize: 16, fontWeight: "700", marginTop: 4, marginBottom: 4 },
  articleCard: { borderRadius: 14, borderWidth: 1, padding: 14, gap: 8 },
  catBadge: { alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  catBadgeText: { fontSize: 11, fontWeight: "700" },
  articleTitle: { fontSize: 15, fontWeight: "700", lineHeight: 22 },
  articleSummary: { fontSize: 13, lineHeight: 19 },
  articleFooter: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  readTimeRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  readTimeText: { fontSize: 11 },
  tagsRow: { flexDirection: "row", gap: 4 },
  tagPill: { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 6 },
  tagPillText: { fontSize: 10 },
  featuredCard: { width: 200, borderRadius: 14, padding: 16, minHeight: 110, gap: 8, justifyContent: "space-between" },
  featuredCatBadge: { alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  featuredCatText: { color: "#FFFFFF", fontSize: 10, fontWeight: "700" },
  featuredTitle: { color: "#FFFFFF", fontSize: 14, fontWeight: "700", lineHeight: 20 },
  featuredFooter: { flexDirection: "row", alignItems: "center", gap: 4 },
  featuredTime: { color: "rgba(255,255,255,0.8)", fontSize: 11 },
  emptyBox: { alignItems: "center", paddingTop: 60, gap: 8 },
  emptyEmoji: { fontSize: 40 },
  emptyText: { fontSize: 16, fontWeight: "600" },
  emptySubText: { fontSize: 13 },
  // Delivery
  trustBanner: { padding: 14, borderRadius: 14, borderWidth: 1, gap: 0 },
  trustRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  trustIconBox: { width: 40, height: 40, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  trustTitle: { fontSize: 15, fontWeight: "700" },
  trustSub: { fontSize: 12, marginTop: 2 },
  statsRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  statCard: { flex: 1, minWidth: "45%", padding: 12, borderRadius: 12, borderWidth: 1, alignItems: "center", gap: 4 },
  statValue: { fontSize: 18, fontWeight: "800" },
  statLabel: { fontSize: 11, textAlign: "center" },
  deliveryCard: { borderRadius: 14, borderWidth: 1, overflow: "hidden" },
  deliveryHeader: { padding: 12, gap: 6 },
  deliveryOrderRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  deliveryOrderCode: { fontSize: 14, fontWeight: "800", letterSpacing: 0.5 },
  deliveryDate: { fontSize: 12 },
  statusBadge: { alignSelf: "flex-start", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  statusText: { fontSize: 12, fontWeight: "700" },
  productList: { paddingHorizontal: 12, paddingVertical: 8, borderTopWidth: 0.5, gap: 4 },
  productRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  productDot: { width: 6, height: 6, borderRadius: 3 },
  productName: { fontSize: 13, fontWeight: "600", flex: 1 },
  productFlavor: { fontSize: 12 },
  deliveryFooter: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", padding: 12, borderTopWidth: 0.5, gap: 8 },
  footerLeft: { gap: 4, flex: 1 },
  footerItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  footerText: { fontSize: 11 },
  totalText: { fontSize: 16, fontWeight: "800" },
  // Photo Review
  uploadBox: { padding: 20, borderRadius: 16, borderWidth: 1, gap: 10, alignItems: "center" },
  uploadTitle: { fontSize: 17, fontWeight: "700" },
  uploadSub: { fontSize: 13, textAlign: "center", lineHeight: 19 },
  uploadBtns: { flexDirection: "row", gap: 12, marginTop: 4 },
  uploadBtn: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12 },
  uploadBtnText: { color: "#FFFFFF", fontSize: 14, fontWeight: "700" },
  reviewCard: { flexDirection: "row", borderRadius: 14, borderWidth: 1, overflow: "hidden" },
  reviewImage: { width: 100, height: 100 },
  reviewContent: { flex: 1, padding: 12, gap: 4 },
  reviewProduct: { fontSize: 13, fontWeight: "700" },
  reviewStars: { flexDirection: "row", gap: 2 },
  reviewComment: { fontSize: 12, lineHeight: 18 },
  reviewDate: { fontSize: 10, marginTop: 2 },
  // Form
  imagePreviewBox: { position: "relative", borderRadius: 16, overflow: "hidden" },
  imagePreview: { width: "100%", height: 220, borderRadius: 16 },
  imageRemoveBtn: { position: "absolute", top: 10, right: 10, width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  formLabel: { fontSize: 14, fontWeight: "700" },
  formInput: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14 },
  formTextArea: { height: 100 },
  starRow: { flexDirection: "row", gap: 8 },
  starBtn: { padding: 4 },
  submitBtn: { padding: 16, borderRadius: 14, alignItems: "center" },
  submitBtnText: { color: "#FFFFFF", fontSize: 16, fontWeight: "700" },
  // Search & Sort
  sortBtn: {
    width: 44,
    height: 44,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  sortDropdown: {
    borderRadius: 12,
    borderWidth: 1,
    overflow: "hidden",
  },
  sortOption: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  sortOptionText: { fontSize: 14 },
  filterStatusRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  resultCount: { fontSize: 13 },
  clearBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
  },
  clearBtnText: { fontSize: 12, fontWeight: "600" },
  // LINE CTA Banner
  lineCTABanner: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#06C755",
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    gap: 12,
  },
  lineCTAIcon: { fontSize: 24 },
  lineCTATitle: { color: "#FFFFFF", fontSize: 14, fontWeight: "800" },
  lineCTASub: { color: "rgba(255,255,255,0.85)", fontSize: 12, marginTop: 2 },
  serviceBadgesRow: {
    flexDirection: "row",
    gap: 8,
  },
  serviceBadge: {
    flex: 1,
    borderRadius: 14,
    padding: 12,
    alignItems: "center",
    gap: 4,
  },
  serviceBadgeIcon: { fontSize: 22 },
  serviceBadgeText: {
    color: "#FFFFFF",
    fontSize: 11,
    fontWeight: "700",
    textAlign: "center",
    lineHeight: 15,
  },
  // icon arrow.up.arrow.down placeholder
});
