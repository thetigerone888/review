import {
  View, Text, ScrollView, Pressable, StyleSheet, Alert
} from "react-native";
import { useState, useEffect, useCallback } from "react";
import { router } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { TagChip } from "@/components/ui/tag-chip";
import { useColors } from "@/hooks/use-colors";
import {
  loadFeedbacks, loadTags, computeStats, computeNPSTrend, computeTagStats, exportFeedbacksToCSV
} from "@/lib/data";
import type { FeedbackItem, FeedbackTag, DashboardStats, NPSTrend, TagStat } from "@/lib/types";

type DateRange = "7d" | "30d" | "90d";

export default function AnalyticsScreen() {
  const colors = useColors();
  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>([]);
  const [tags, setTags] = useState<FeedbackTag[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalResponses: 0, npsScore: 0, avgRating: 0, responseRate: 0,
    positiveCount: 0, neutralCount: 0, negativeCount: 0,
  });
  const [trend, setTrend] = useState<NPSTrend[]>([]);
  const [tagStats, setTagStats] = useState<TagStat[]>([]);
  const [dateRange, setDateRange] = useState<DateRange>("7d");

  const loadData = useCallback(async () => {
    const [fb, tg] = await Promise.all([loadFeedbacks(), loadTags()]);
    setFeedbacks(fb);
    setTags(tg);
    setStats(computeStats(fb));
    setTrend(computeNPSTrend());
    setTagStats(computeTagStats(fb, tg));
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleExport = () => {
    const csv = exportFeedbacksToCSV(feedbacks, tags);
    Alert.alert(
      "ส่งออกรายงาน",
      `พร้อมส่งออก ${feedbacks.length} รายการ\n\nในอุปกรณ์จริงจะบันทึกไฟล์ CSV ลงเครื่อง`,
      [{ text: "ตกลง" }]
    );
  };

  const maxTrend = Math.max(...trend.map((t) => t.score), 1);
  const total = stats.totalResponses || 1;

  // Volume chart (mock weekly data)
  const volumeData = [12, 18, 15, 22, 28, 20, 25];
  const volumeDays = ["จ", "อ", "พ", "พฤ", "ศ", "ส", "อา"];
  const maxVol = Math.max(...volumeData, 1);

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="chevron.left" size={24} color={colors.primary} />
        </Pressable>
        <Text style={[styles.title, { color: colors.foreground }]}>วิเคราะห์ข้อมูล</Text>
        <Pressable
          onPress={handleExport}
          style={[styles.exportBtn, { backgroundColor: colors.primary }]}
        >
          <IconSymbol name="square.and.arrow.up" size={16} color="#FFFFFF" />
          <Text style={styles.exportText}>ส่งออก</Text>
        </Pressable>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
        {/* Date Range */}
        <View style={styles.dateRange}>
          {(["7d", "30d", "90d"] as DateRange[]).map((r) => (
            <Pressable
              key={r}
              onPress={() => setDateRange(r)}
              style={[
                styles.rangeBtn,
                dateRange === r
                  ? { backgroundColor: colors.primary }
                  : { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 },
              ]}
            >
              <Text style={[styles.rangeText, { color: dateRange === r ? "#FFFFFF" : colors.foreground }]}>
                {r === "7d" ? "7 วัน" : r === "30d" ? "30 วัน" : "90 วัน"}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Summary Stats */}
        <View style={styles.statsGrid}>
          <StatBox label="ทั้งหมด" value={String(stats.totalResponses)} color={colors.primary} />
          <StatBox label="NPS" value={String(stats.npsScore)} color="#8B5CF6" />
          <StatBox label="เฉลี่ย ★" value={String(stats.avgRating)} color="#F59E0B" />
          <StatBox label="ตอบกลับ" value={`${stats.responseRate}%`} color="#10B981" />
        </View>

        {/* NPS Trend Chart */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>แนวโน้ม NPS</Text>
          <View style={styles.lineChart}>
            {trend.map((point, i) => (
              <View key={i} style={styles.lineBar}>
                <Text style={[styles.lineValue, { color: colors.primary }]}>{point.score}</Text>
                <View
                  style={[
                    styles.lineBarFill,
                    {
                      height: `${(point.score / maxTrend) * 100}%`,
                      backgroundColor: i === trend.length - 1 ? colors.primary : `${colors.primary}60`,
                    },
                  ]}
                />
                <Text style={[styles.lineLabel, { color: colors.muted }]}>{point.date}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Sentiment Pie */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>สัดส่วนความรู้สึก</Text>
          <View style={styles.pieContainer}>
            <View style={styles.pieChart}>
              <PieSlice pct={stats.positiveCount / total} color={colors.success} label="บวก" />
              <PieSlice pct={stats.neutralCount / total} color={colors.warning} label="กลาง" />
              <PieSlice pct={stats.negativeCount / total} color={colors.error} label="ลบ" />
            </View>
            <View style={styles.pieLegend}>
              <LegendItem color={colors.success} label="เชิงบวก" count={stats.positiveCount} total={total} />
              <LegendItem color={colors.warning} label="กลาง" count={stats.neutralCount} total={total} />
              <LegendItem color={colors.error} label="เชิงลบ" count={stats.negativeCount} total={total} />
            </View>
          </View>
        </View>

        {/* Volume Chart */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>ปริมาณความคิดเห็น (รายวัน)</Text>
          <View style={styles.volChart}>
            {volumeData.map((v, i) => (
              <View key={i} style={styles.volBar}>
                <Text style={[styles.volValue, { color: colors.muted }]}>{v}</Text>
                <View
                  style={[
                    styles.volBarFill,
                    {
                      height: `${(v / maxVol) * 100}%`,
                      backgroundColor: `${colors.primary}80`,
                    },
                  ]}
                />
                <Text style={[styles.volLabel, { color: colors.muted }]}>{volumeDays[i]}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Top Tags */}
        {tagStats.length > 0 && (
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>แท็กยอดนิยม</Text>
            <View style={styles.tagsList}>
              {tagStats.slice(0, 8).map((ts) => {
                const tag = tags.find((t) => t.id === ts.tagId);
                return tag ? (
                  <View key={ts.tagId} style={styles.tagStatRow}>
                    <TagChip label={tag.label} color={tag.color} size="sm" />
                    <View style={[styles.tagTrack, { backgroundColor: colors.border }]}>
                      <View
                        style={[
                          styles.tagFill,
                          {
                            width: `${(ts.count / (tagStats[0]?.count ?? 1)) * 100}%`,
                            backgroundColor: tag.color,
                          },
                        ]}
                      />
                    </View>
                    <Text style={[styles.tagCount, { color: colors.muted }]}>{ts.count}</Text>
                  </View>
                ) : null;
              })}
            </View>
          </View>
        )}

        {/* NPS Breakdown */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>การแบ่งกลุ่ม NPS</Text>
          <View style={styles.npsBreakdown}>
            <NPSGroup
              label="Promoters"
              subtitle="คะแนน 9-10"
              count={feedbacks.filter((f) => (f.npsScore ?? 0) >= 9).length}
              color="#10B981"
            />
            <NPSGroup
              label="Passives"
              subtitle="คะแนน 7-8"
              count={feedbacks.filter((f) => (f.npsScore ?? 0) >= 7 && (f.npsScore ?? 0) <= 8).length}
              color="#F59E0B"
            />
            <NPSGroup
              label="Detractors"
              subtitle="คะแนน 0-6"
              count={feedbacks.filter((f) => (f.npsScore ?? 0) <= 6 && f.npsScore !== undefined).length}
              color="#EF4444"
            />
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function StatBox({ label, value, color }: { label: string; value: string; color: string }) {
  const colors = useColors();
  return (
    <View style={[styles.statBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <Text style={[styles.statValue, { color }]}>{value}</Text>
      <Text style={[styles.statLabel, { color: colors.muted }]}>{label}</Text>
    </View>
  );
}

function PieSlice({ pct, color, label }: { pct: number; color: string; label: string }) {
  const height = Math.max(pct * 120, 4);
  return (
    <View style={styles.pieSlice}>
      <View style={[styles.pieBar, { height, backgroundColor: color }]} />
      <Text style={[styles.pieLabel, { color }]}>{Math.round(pct * 100)}%</Text>
    </View>
  );
}

function LegendItem({ color, label, count, total }: { color: string; label: string; count: number; total: number }) {
  const colors = useColors();
  return (
    <View style={styles.legendItem}>
      <View style={[styles.legendDot, { backgroundColor: color }]} />
      <Text style={[styles.legendLabel, { color: colors.foreground }]}>{label}</Text>
      <Text style={[styles.legendPct, { color: colors.muted }]}>
        {count} ({Math.round((count / total) * 100)}%)
      </Text>
    </View>
  );
}

function NPSGroup({ label, subtitle, count, color }: { label: string; subtitle: string; count: number; color: string }) {
  const colors = useColors();
  return (
    <View style={[styles.npsGroup, { backgroundColor: `${color}10`, borderColor: `${color}40` }]}>
      <Text style={[styles.npsGroupLabel, { color }]}>{label}</Text>
      <Text style={[styles.npsGroupCount, { color }]}>{count}</Text>
      <Text style={[styles.npsGroupSub, { color: colors.muted }]}>{subtitle}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
    gap: 8,
  },
  backBtn: { padding: 4 },
  title: { flex: 1, fontSize: 18, fontWeight: "700" },
  exportBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 16,
  },
  exportText: { color: "#FFFFFF", fontSize: 13, fontWeight: "600" },
  dateRange: {
    flexDirection: "row",
    gap: 8,
    padding: 16,
  },
  rangeBtn: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 10,
    alignItems: "center",
  },
  rangeText: { fontSize: 13, fontWeight: "600" },
  statsGrid: {
    flexDirection: "row",
    paddingHorizontal: 16,
    gap: 10,
    marginBottom: 8,
  },
  statBox: {
    flex: 1,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: "center",
    gap: 4,
  },
  statValue: { fontSize: 20, fontWeight: "800" },
  statLabel: { fontSize: 10, fontWeight: "500" },
  card: {
    margin: 16,
    marginBottom: 0,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 16,
  },
  cardTitle: { fontSize: 15, fontWeight: "700" },
  lineChart: {
    flexDirection: "row",
    alignItems: "flex-end",
    height: 100,
    gap: 8,
  },
  lineBar: {
    flex: 1,
    alignItems: "center",
    height: "100%",
    justifyContent: "flex-end",
    gap: 4,
  },
  lineValue: { fontSize: 10, fontWeight: "700" },
  lineBarFill: { width: "100%", borderRadius: 4, minHeight: 4 },
  lineLabel: { fontSize: 9 },
  pieContainer: { flexDirection: "row", alignItems: "center", gap: 16 },
  pieChart: {
    flexDirection: "row",
    alignItems: "flex-end",
    height: 120,
    gap: 12,
  },
  pieSlice: { alignItems: "center", gap: 4 },
  pieBar: { width: 40, borderRadius: 6 },
  pieLabel: { fontSize: 11, fontWeight: "700" },
  pieLegend: { flex: 1, gap: 8 },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 8 },
  legendDot: { width: 10, height: 10, borderRadius: 5 },
  legendLabel: { fontSize: 13, flex: 1 },
  legendPct: { fontSize: 12 },
  volChart: {
    flexDirection: "row",
    alignItems: "flex-end",
    height: 80,
    gap: 6,
  },
  volBar: {
    flex: 1,
    alignItems: "center",
    height: "100%",
    justifyContent: "flex-end",
    gap: 4,
  },
  volValue: { fontSize: 9, fontWeight: "600" },
  volBarFill: { width: "100%", borderRadius: 4, minHeight: 4 },
  volLabel: { fontSize: 9 },
  tagsList: { gap: 10 },
  tagStatRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  tagTrack: { flex: 1, height: 6, borderRadius: 3, overflow: "hidden" },
  tagFill: { height: "100%", borderRadius: 3 },
  tagCount: { fontSize: 12, fontWeight: "600", width: 20, textAlign: "right" },
  npsBreakdown: { flexDirection: "row", gap: 10 },
  npsGroup: {
    flex: 1,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: "center",
    gap: 4,
  },
  npsGroupLabel: { fontSize: 12, fontWeight: "700" },
  npsGroupCount: { fontSize: 24, fontWeight: "800" },
  npsGroupSub: { fontSize: 10 },
});
