import {
  View, Text, ScrollView, Pressable, StyleSheet, Alert, TextInput, Modal
} from "react-native";
import { useState, useEffect } from "react";
import { useLocalSearchParams, router } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { SentimentBadge } from "@/components/ui/sentiment-badge";
import { StarRating } from "@/components/ui/star-rating";
import { TagChip } from "@/components/ui/tag-chip";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { loadFeedbacks, loadTags, saveFeedbacks } from "@/lib/data";
import type { FeedbackItem, FeedbackTag } from "@/lib/types";

const CHANNEL_LABELS: Record<string, string> = {
  survey: "แบบสอบถาม", email: "อีเมล", sms: "SMS", qr: "QR Code", direct: "ตรง",
};

export default function FeedbackDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const [feedback, setFeedback] = useState<FeedbackItem | null>(null);
  const [allTags, setAllTags] = useState<FeedbackTag[]>([]);
  const [showTagModal, setShowTagModal] = useState(false);

  useEffect(() => {
    (async () => {
      const [fbs, tgs] = await Promise.all([loadFeedbacks(), loadTags()]);
      setFeedback(fbs.find((f) => f.id === id) ?? null);
      setAllTags(tgs);
    })();
  }, [id]);

  if (!feedback) {
    return (
      <ScreenContainer>
        <View style={styles.loading}>
          <Text style={{ color: colors.muted }}>กำลังโหลด...</Text>
        </View>
      </ScreenContainer>
    );
  }

  const itemTags = allTags.filter((t) => feedback.tags.includes(t.id));
  const availableTags = allTags.filter((t) => !feedback.tags.includes(t.id));

  const addTag = async (tagId: string) => {
    const updated = { ...feedback, tags: [...feedback.tags, tagId] };
    setFeedback(updated);
    const all = await loadFeedbacks();
    await saveFeedbacks(all.map((f) => (f.id === id ? updated : f)));
  };

  const removeTag = async (tagId: string) => {
    const updated = { ...feedback, tags: feedback.tags.filter((t) => t !== tagId) };
    setFeedback(updated);
    const all = await loadFeedbacks();
    await saveFeedbacks(all.map((f) => (f.id === id ? updated : f)));
  };

  const archiveFeedback = async () => {
    Alert.alert("เก็บถาวร", "ต้องการเก็บถาวรความคิดเห็นนี้?", [
      { text: "ยกเลิก", style: "cancel" },
      {
        text: "เก็บถาวร",
        onPress: async () => {
          const updated = { ...feedback, isArchived: true };
          const all = await loadFeedbacks();
          await saveFeedbacks(all.map((f) => (f.id === id ? updated : f)));
          router.back();
        },
      },
    ]);
  };

  const npsColor = feedback.npsScore !== undefined
    ? feedback.npsScore >= 9 ? colors.success : feedback.npsScore >= 7 ? colors.warning : colors.error
    : colors.muted;

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="chevron.left" size={24} color={colors.primary} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>รายละเอียด</Text>
        <Pressable onPress={archiveFeedback} style={styles.archiveBtn}>
          <IconSymbol name="archivebox.fill" size={20} color={colors.muted} />
        </Pressable>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
        {/* Customer Info */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.customerRow}>
            <View style={[styles.avatar, { backgroundColor: `${colors.primary}20` }]}>
              <Text style={[styles.avatarText, { color: colors.primary }]}>
                {feedback.customerName.charAt(0)}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.customerName, { color: colors.foreground }]}>{feedback.customerName}</Text>
              {feedback.customerEmail && (
                <Text style={[styles.customerEmail, { color: colors.muted }]}>{feedback.customerEmail}</Text>
              )}
              <Text style={[styles.meta, { color: colors.muted }]}>
                {CHANNEL_LABELS[feedback.channel]} · {new Date(feedback.createdAt).toLocaleDateString("th-TH", { day: "numeric", month: "long", year: "numeric" })}
              </Text>
            </View>
            <SentimentBadge sentiment={feedback.sentiment} />
          </View>
        </View>

        {/* Ratings */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>คะแนน</Text>
          <View style={styles.ratingsRow}>
            <View style={styles.ratingItem}>
              <Text style={[styles.ratingLabel, { color: colors.muted }]}>ดาว</Text>
              <StarRating value={feedback.rating} size={24} readonly />
              <Text style={[styles.ratingValue, { color: colors.foreground }]}>{feedback.rating}/5</Text>
            </View>
            {feedback.npsScore !== undefined && (
              <View style={[styles.npsBox, { backgroundColor: `${npsColor}15`, borderColor: npsColor }]}>
                <Text style={[styles.npsLabel, { color: colors.muted }]}>NPS Score</Text>
                <Text style={[styles.npsValue, { color: npsColor }]}>{feedback.npsScore}</Text>
                <Text style={[styles.npsCategory, { color: npsColor }]}>
                  {feedback.npsScore >= 9 ? "Promoter" : feedback.npsScore >= 7 ? "Passive" : "Detractor"}
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Sentiment Analysis */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>การวิเคราะห์ความรู้สึก</Text>
          <View style={styles.sentimentRow}>
            <SentimentBadge sentiment={feedback.sentiment} />
            <View style={styles.confidenceBar}>
              <View style={[styles.confidenceTrack, { backgroundColor: colors.border }]}>
                <View
                  style={[
                    styles.confidenceFill,
                    {
                      width: `${feedback.sentimentConfidence * 100}%`,
                      backgroundColor: feedback.sentiment === "positive" ? colors.success : feedback.sentiment === "negative" ? colors.error : colors.warning,
                    },
                  ]}
                />
              </View>
              <Text style={[styles.confidenceText, { color: colors.muted }]}>
                {Math.round(feedback.sentimentConfidence * 100)}% ความมั่นใจ
              </Text>
            </View>
          </View>
        </View>

        {/* Comment */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>ความคิดเห็น</Text>
          <Text style={[styles.comment, { color: colors.foreground }]}>{feedback.comment}</Text>
        </View>

        {/* Tags */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.tagsHeader}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>แท็ก</Text>
            <Pressable
              onPress={() => setShowTagModal(true)}
              style={[styles.addTagBtn, { backgroundColor: `${colors.primary}15` }]}
            >
              <IconSymbol name="plus" size={14} color={colors.primary} />
              <Text style={[styles.addTagText, { color: colors.primary }]}>เพิ่มแท็ก</Text>
            </Pressable>
          </View>
          <View style={styles.tagsList}>
            {itemTags.length === 0 ? (
              <Text style={[styles.noTags, { color: colors.muted }]}>ยังไม่มีแท็ก</Text>
            ) : (
              itemTags.map((tag) => (
                <TagChip key={tag.id} label={tag.label} color={tag.color} onRemove={() => removeTag(tag.id)} />
              ))
            )}
          </View>
        </View>
      </ScrollView>

      {/* Tag Modal */}
      <Modal visible={showTagModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.surface }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>เลือกแท็ก</Text>
              <Pressable onPress={() => setShowTagModal(false)}>
                <IconSymbol name="xmark.circle.fill" size={24} color={colors.muted} />
              </Pressable>
            </View>
            <View style={styles.tagOptions}>
              {availableTags.map((tag) => (
                <Pressable
                  key={tag.id}
                  onPress={() => { addTag(tag.id); setShowTagModal(false); }}
                >
                  <TagChip label={tag.label} color={tag.color} />
                </Pressable>
              ))}
              {availableTags.length === 0 && (
                <Text style={[styles.noTags, { color: colors.muted }]}>เพิ่มแท็กทั้งหมดแล้ว</Text>
              )}
            </View>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
  },
  backBtn: { padding: 4 },
  headerTitle: { flex: 1, fontSize: 18, fontWeight: "700", textAlign: "center" },
  archiveBtn: { padding: 4 },
  card: {
    margin: 16,
    marginBottom: 0,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 12,
  },
  cardTitle: { fontSize: 14, fontWeight: "700" },
  customerRow: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  avatar: { width: 48, height: 48, borderRadius: 24, alignItems: "center", justifyContent: "center" },
  avatarText: { fontSize: 20, fontWeight: "700" },
  customerName: { fontSize: 16, fontWeight: "700" },
  customerEmail: { fontSize: 13, marginTop: 2 },
  meta: { fontSize: 12, marginTop: 2 },
  ratingsRow: { flexDirection: "row", alignItems: "center", gap: 16 },
  ratingItem: { gap: 6 },
  ratingLabel: { fontSize: 12 },
  ratingValue: { fontSize: 13, fontWeight: "600" },
  npsBox: {
    flex: 1,
    alignItems: "center",
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    gap: 4,
  },
  npsLabel: { fontSize: 11 },
  npsValue: { fontSize: 32, fontWeight: "800" },
  npsCategory: { fontSize: 12, fontWeight: "600" },
  sentimentRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  confidenceBar: { flex: 1, gap: 4 },
  confidenceTrack: { height: 8, borderRadius: 4, overflow: "hidden" },
  confidenceFill: { height: "100%", borderRadius: 4 },
  confidenceText: { fontSize: 11 },
  comment: { fontSize: 15, lineHeight: 24 },
  tagsHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  addTagBtn: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 },
  addTagText: { fontSize: 13, fontWeight: "600" },
  tagsList: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  noTags: { fontSize: 13 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" },
  modalContent: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, gap: 16 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  modalTitle: { fontSize: 18, fontWeight: "700" },
  tagOptions: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
});
