import { View, Text, StyleSheet } from "react-native";
import type { SentimentType } from "@/lib/types";

interface SentimentBadgeProps {
  sentiment: SentimentType;
  size?: "sm" | "md";
}

const SENTIMENT_CONFIG = {
  positive: { label: "เชิงบวก", emoji: "😊", bg: "#D1FAE5", text: "#065F46" },
  neutral: { label: "กลาง", emoji: "😐", bg: "#FEF3C7", text: "#92400E" },
  negative: { label: "เชิงลบ", emoji: "😞", bg: "#FEE2E2", text: "#991B1B" },
};

export function SentimentBadge({ sentiment, size = "md" }: SentimentBadgeProps) {
  const config = SENTIMENT_CONFIG[sentiment];
  const isSmall = size === "sm";

  return (
    <View style={[styles.badge, { backgroundColor: config.bg }, isSmall && styles.badgeSm]}>
      <Text style={[styles.emoji, isSmall && styles.emojiSm]}>{config.emoji}</Text>
      {!isSmall && (
        <Text style={[styles.label, { color: config.text }]}>{config.label}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    gap: 4,
  },
  badgeSm: {
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  emoji: {
    fontSize: 14,
  },
  emojiSm: {
    fontSize: 12,
  },
  label: {
    fontSize: 12,
    fontWeight: "600",
  },
});
