import { View, Text, Pressable, StyleSheet } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { SentimentBadge } from "./sentiment-badge";
import { StarRating } from "./star-rating";
import { TagChip } from "./tag-chip";
import type { FeedbackItem, FeedbackTag } from "@/lib/types";

interface FeedbackCardProps {
  item: FeedbackItem;
  tags: FeedbackTag[];
  onPress?: () => void;
}

const CHANNEL_LABELS: Record<string, string> = {
  survey: "แบบสอบถาม",
  email: "อีเมล",
  sms: "SMS",
  qr: "QR Code",
  direct: "ตรง",
};

export function FeedbackCard({ item, tags, onPress }: FeedbackCardProps) {
  const colors = useColors();
  const itemTags = tags.filter((t) => item.tags.includes(t.id));
  const timeAgo = getTimeAgo(item.createdAt);

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        { backgroundColor: colors.surface, borderColor: colors.border },
        pressed && { opacity: 0.85 },
      ]}
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.customerInfo}>
          <View style={[styles.avatar, { backgroundColor: `${colors.primary}20` }]}>
            <Text style={[styles.avatarText, { color: colors.primary }]}>
              {item.customerName.charAt(0)}
            </Text>
          </View>
          <View>
            <Text style={[styles.name, { color: colors.foreground }]}>{item.customerName}</Text>
            <Text style={[styles.meta, { color: colors.muted }]}>
              {CHANNEL_LABELS[item.channel]} · {timeAgo}
            </Text>
          </View>
        </View>
        <SentimentBadge sentiment={item.sentiment} size="sm" />
      </View>

      {/* Rating & NPS */}
      <View style={styles.ratingRow}>
        <StarRating value={item.rating} size={16} readonly />
        {item.npsScore !== undefined && (
          <View style={[styles.npsBadge, { backgroundColor: getNPSColor(item.npsScore) + "20" }]}>
            <Text style={[styles.npsText, { color: getNPSColor(item.npsScore) }]}>
              NPS {item.npsScore}
            </Text>
          </View>
        )}
      </View>

      {/* Comment */}
      <Text style={[styles.comment, { color: colors.foreground }]} numberOfLines={2}>
        {item.comment}
      </Text>

      {/* Tags */}
      {itemTags.length > 0 && (
        <View style={styles.tags}>
          {itemTags.map((tag) => (
            <TagChip key={tag.id} label={tag.label} color={tag.color} size="sm" />
          ))}
        </View>
      )}
    </Pressable>
  );
}

function getNPSColor(score: number): string {
  if (score >= 9) return "#10B981";
  if (score >= 7) return "#F59E0B";
  return "#EF4444";
}

function getTimeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins} นาทีที่แล้ว`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} ชั่วโมงที่แล้ว`;
  const days = Math.floor(hours / 24);
  return `${days} วันที่แล้ว`;
}

const styles = StyleSheet.create({
  card: {
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 10,
    marginBottom: 10,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  customerInfo: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    flex: 1,
  },
  avatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    fontSize: 16,
    fontWeight: "700",
  },
  name: {
    fontSize: 14,
    fontWeight: "600",
  },
  meta: {
    fontSize: 12,
    marginTop: 1,
  },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  npsBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
  },
  npsText: {
    fontSize: 11,
    fontWeight: "700",
  },
  comment: {
    fontSize: 14,
    lineHeight: 20,
  },
  tags: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
  },
});
