import { View, Pressable, StyleSheet } from "react-native";
import { IconSymbol } from "./icon-symbol";

interface StarRatingProps {
  value: number;
  onChange?: (value: number) => void;
  size?: number;
  readonly?: boolean;
}

export function StarRating({ value, onChange, size = 24, readonly = false }: StarRatingProps) {
  return (
    <View style={styles.container}>
      {[1, 2, 3, 4, 5].map((star) => (
        <Pressable
          key={star}
          onPress={() => !readonly && onChange?.(star)}
          style={({ pressed }) => [pressed && !readonly && { opacity: 0.7 }]}
          disabled={readonly}
        >
          <IconSymbol
            name={star <= value ? "star.fill" : "star"}
            size={size}
            color={star <= value ? "#F59E0B" : "#D1D5DB"}
          />
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    gap: 2,
  },
});
