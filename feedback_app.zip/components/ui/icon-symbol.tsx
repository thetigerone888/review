// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight } from "expo-symbols";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconSymbolName = keyof typeof MAPPING;

/**
 * SF Symbols to Material Icons mappings for FeedbackPro app.
 */
const MAPPING = {
  // Navigation tabs
  "house.fill": "home",
  "bubble.left.and.bubble.right.fill": "forum",
  "doc.text.fill": "assignment",
  "cart.fill": "shopping-cart",
  "phone.fill": "phone",
  // Common actions
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "chevron.down": "expand-more",
  "chevron.up": "expand-less",
  "plus": "add",
  "plus.circle.fill": "add-circle",
  "minus.circle.fill": "remove-circle",
  "xmark": "close",
  "xmark.circle.fill": "cancel",
  "checkmark": "check",
  "checkmark.circle.fill": "check-circle",
  "magnifyingglass": "search",
  "slider.horizontal.3": "tune",
  "arrow.up.arrow.down": "swap-vert",
  "square.and.arrow.up": "ios-share",
  "square.and.arrow.down": "download",
  "trash.fill": "delete",
  "archivebox.fill": "archive",
  "pencil": "edit",
  "bell.fill": "notifications",
  "gear": "settings",
  "info.circle": "info",
  "exclamationmark.triangle.fill": "warning",
  // Feedback & Survey
  "star.fill": "star",
  "star": "star-outline",
  "heart.fill": "favorite",
  "face.smiling": "sentiment-satisfied",
  "face.dashed": "sentiment-neutral",
  "face.smiling.inverse": "sentiment-dissatisfied",
  "chart.bar.fill": "bar-chart",
  "chart.line.uptrend.xyaxis": "trending-up",
  "chart.pie.fill": "pie-chart",
  "tag.fill": "label",
  "qrcode": "qr-code",
  "link": "link",
  "envelope.fill": "email",
  "message.fill": "message",
  "person.fill": "person",
  "person.2.fill": "people",
  // Product
  "bag.fill": "shopping-bag",
  "cube.box.fill": "inventory-2",
  "photo.fill": "image",
  // Contact
  "phone.arrow.up.right": "call",
  "globe": "language",
  "location.fill": "location-on",
  "clock.fill": "access-time",
  "camera.fill": "camera-alt",
  "facebook": "facebook",
  "line": "chat",
  "instagram": "camera-alt",
  // Info icons
  "bolt.fill": "bolt",
  "checkmark.seal.fill": "verified",
  "lock.fill": "lock",
  "shield.fill": "security",
  "truck.box.fill": "local-shipping",
  // Knowledge
  "book.fill": "menu-book",
  "lightbulb.fill": "lightbulb",
  "newspaper.fill": "article",
  "bookmark.fill": "bookmark",
  "eye.fill": "visibility",
} as const;

/**
 * An icon component that uses native SF Symbols on iOS, and Material Icons on Android and web.
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
