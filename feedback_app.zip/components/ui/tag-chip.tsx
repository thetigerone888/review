import { View, Text, Pressable, StyleSheet } from "react-native";
import { IconSymbol } from "./icon-symbol";

interface TagChipProps {
  label: string;
  color?: string;
  onRemove?: () => void;
  onPress?: () => void;
  selected?: boolean;
  size?: "sm" | "md";
}

export function TagChip({ label, color = "#4F46E5", onRemove, onPress, selected = false, size = "md" }: TagChipProps) {
  const isSmall = size === "sm";
  const bgColor = selected ? color : `${color}20`;
  const textColor = selected ? "#FFFFFF" : color;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.chip,
        isSmall && styles.chipSm,
        { backgroundColor: bgColor },
        pressed && { opacity: 0.7 },
      ]}
    >
      <Text style={[styles.label, isSmall && styles.labelSm, { color: textColor }]}>{label}</Text>
      {onRemove && (
        <Pressable onPress={onRemove} style={styles.removeBtn}>
          <IconSymbol name="xmark" size={10} color={textColor} />
        </Pressable>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  chip: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
    gap: 4,
  },
  chipSm: {
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  label: {
    fontSize: 13,
    fontWeight: "600",
  },
  labelSm: {
    fontSize: 11,
  },
  removeBtn: {
    marginLeft: 2,
  },
});
