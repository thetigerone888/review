import { Pressable, StyleSheet, Linking, View, Text, Animated } from "react-native";
import { useEffect, useRef } from "react";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const LINE_URL = "https://lin.ee/uxfvSkp";

export function LineFloatingButton() {
  const insets = useSafeAreaInsets();
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.12,
          duration: 900,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 900,
          useNativeDriver: true,
        }),
      ])
    );
    pulse.start();
    return () => pulse.stop();
  }, [pulseAnim]);

  const handlePress = () => {
    Linking.openURL(LINE_URL);
  };

  return (
    <View
      style={[
        styles.container,
        { bottom: Math.max(insets.bottom, 16) + 72 }, // above tab bar
      ]}
      pointerEvents="box-none"
    >
      {/* Pulse ring */}
      <Animated.View
        style={[
          styles.pulseRing,
          { transform: [{ scale: pulseAnim }] },
        ]}
      />
      <Pressable
        onPress={handlePress}
        style={({ pressed }) => [
          styles.button,
          pressed && { opacity: 0.85, transform: [{ scale: 0.96 }] },
        ]}
      >
        {/* LINE logo */}
        <View style={styles.lineIcon}>
          <Text style={styles.lineIconText}>LINE</Text>
        </View>
        <Text style={styles.label}>24 ชม.</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: "absolute",
    right: 16,
    alignItems: "center",
    zIndex: 999,
  },
  pulseRing: {
    position: "absolute",
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "rgba(0, 195, 0, 0.2)",
    top: -4,
  },
  button: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: "#00C300",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#00C300",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
    gap: 1,
  },
  lineIcon: {
    alignItems: "center",
    justifyContent: "center",
  },
  lineIconText: {
    color: "#FFFFFF",
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 0.5,
  },
  label: {
    color: "#FFFFFF",
    fontSize: 7,
    fontWeight: "700",
    letterSpacing: 0.2,
  },
});
