import { View, Text, Pressable, StyleSheet } from "react-native";
import { IconSymbol } from "./icon-symbol";
import { useColors } from "@/hooks/use-colors";

interface KPICardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: string;
  iconColor?: string;
  trend?: number; // positive = up, negative = down
  onPress?: () => void;
}

export function KPICard({ title, value, subtitle, icon, iconColor, trend, onPress }: KPICardProps) {
  const colors = useColors();
  const trendColor = trend === undefined ? colors.muted : trend >= 0 ? colors.success : colors.error;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        { backgroundColor: colors.surface, borderColor: colors.border },
        pressed && { opacity: 0.85 },
      ]}
    >
      <View style={styles.header}>
        <View style={[styles.iconBg, { backgroundColor: `${iconColor ?? colors.primary}18` }]}>
          <IconSymbol name={icon as any} size={20} color={iconColor ?? colors.primary} />
        </View>
        {trend !== undefined && (
          <View style={styles.trend}>
            <IconSymbol
              name={trend >= 0 ? "chart.line.uptrend.xyaxis" : "chevron.down"}
              size={12}
              color={trendColor}
            />
            <Text style={[styles.trendText, { color: trendColor }]}>
              {Math.abs(trend)}%
            </Text>
          </View>
        )}
      </View>
      <Text style={[styles.value, { color: colors.foreground }]}>{value}</Text>
      <Text style={[styles.title, { color: colors.muted }]}>{title}</Text>
      {subtitle && <Text style={[styles.subtitle, { color: colors.muted }]}>{subtitle}</Text>}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 4,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  iconBg: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  trend: {
    flexDirection: "row",
    alignItems: "center",
    gap: 2,
  },
  trendText: {
    fontSize: 11,
    fontWeight: "600",
  },
  value: {
    fontSize: 26,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  title: {
    fontSize: 12,
    fontWeight: "500",
  },
  subtitle: {
    fontSize: 11,
    marginTop: 2,
  },
});
