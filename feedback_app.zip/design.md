# Customer Feedback App — Design Document

## App Overview
แอปมือถือสำหรับธุรกิจที่ต้องการรวบรวมและวิเคราะห์ความคิดเห็นลูกค้า ออกแบบสำหรับ iOS portrait orientation และการใช้งานด้วยมือเดียว

---

## Brand & Color Palette

| Token | Light | Dark | Usage |
|-------|-------|------|-------|
| `primary` | `#4F46E5` (Indigo) | `#6366F1` | CTA, active tabs, highlights |
| `background` | `#F8F9FF` | `#0F0F1A` | Screen background |
| `surface` | `#FFFFFF` | `#1A1A2E` | Cards, modals |
| `foreground` | `#1E1B4B` | `#E8E8FF` | Primary text |
| `muted` | `#6B7280` | `#9CA3AF` | Secondary text |
| `border` | `#E5E7EB` | `#2D2D4A` | Dividers, borders |
| `success` | `#10B981` | `#34D399` | Positive sentiment |
| `warning` | `#F59E0B` | `#FBBF24` | Neutral sentiment |
| `error` | `#EF4444` | `#F87171` | Negative sentiment |
| `accent` | `#8B5CF6` | `#A78BFA` | NPS promoter zone |

---

## Screen List

### Tab Navigation (5 tabs)
1. **Dashboard** — ภาพรวมสถิติและ KPI
2. **Feedback** — รายการความคิดเห็นและการกรอง
3. **Survey** — สร้างและแจกแบบสอบถาม
4. **Catalog** — แคตตาล็อกสินค้า
5. **Contact** — ช่องทางติดต่อ

### Additional Screens
- **Survey Detail / Fill Survey** — หน้ากรอกแบบสอบถาม
- **Feedback Detail** — รายละเอียดความคิดเห็นพร้อมแท็ก
- **Analytics** — กราฟและการวิเคราะห์เชิงลึก
- **Product Detail** — รายละเอียดสินค้า
- **Export** — ส่งออกข้อมูล

---

## Screen Details

### 1. Dashboard Screen
**Primary Content:**
- Header: ชื่อแอป + ปุ่ม Analytics
- KPI Cards (2x2 grid): Total Responses, NPS Score, Avg Rating, Response Rate
- Sentiment Overview: Bar chart (Positive/Neutral/Negative)
- Recent Feedback: FlatList รายการล่าสุด 5 รายการ
- Quick Actions: "New Survey" button

**Functionality:**
- Pull-to-refresh เพื่ออัปเดตข้อมูล
- Tap KPI card → Analytics screen
- Tap feedback item → Feedback Detail

### 2. Feedback Screen
**Primary Content:**
- Search bar
- Filter chips: All / Positive / Neutral / Negative / Tagged
- FlatList ของ feedback cards แสดง: rating, sentiment badge, tags, timestamp
- Sort options: Latest / Oldest / Rating

**Functionality:**
- ค้นหาและกรองความคิดเห็น
- Tap item → Feedback Detail screen
- Swipe left → Delete / Archive
- Export button (top right)

### 3. Feedback Detail Screen
**Primary Content:**
- Customer info (name, channel, date)
- Full feedback text
- Star rating display
- NPS score badge
- Sentiment analysis result + confidence %
- Tags section (add/remove tags)
- Action buttons: Reply, Archive, Export

### 4. Survey Screen
**Primary Content:**
- Active surveys list
- "Create Survey" FAB button
- Survey cards: title, response count, status, channels

**Functionality:**
- Create new survey (NPS, Star Rating, Multiple Choice, Open Text)
- Share via: Link, QR Code, Email, SMS
- View responses per survey

### 5. Survey Fill Screen (Public-facing)
**Primary Content:**
- Progress bar
- Question display (NPS scale 0-10, Stars 1-5, Multiple choice, Text area)
- Next/Submit buttons

### 6. Analytics Screen
**Primary Content:**
- Date range picker
- NPS Trend line chart
- Sentiment pie chart
- Top tags word cloud (as tag list)
- Response volume bar chart
- Export report button

### 7. Catalog Screen
**Primary Content:**
- Search bar
- Category filter chips
- Product grid (2 columns): image, name, price, rating
- Featured products section

**Functionality:**
- Tap product → Product Detail
- Filter by category
- Search products

### 8. Product Detail Screen
**Primary Content:**
- Product image (full width)
- Name, price, description
- Customer reviews section
- "Leave Feedback" button → Survey Fill

### 9. Contact Screen
**Primary Content:**
- Company info card
- Contact channels list: Phone, Email, LINE, Facebook, Website
- Map/Location section
- Business hours
- Contact form (Name, Email, Message, Send button)

---

## Key User Flows

### Flow 1: Customer Submits Feedback
Survey link/QR → Fill Survey Screen → Submit → Thank you message

### Flow 2: Admin Reviews Feedback
Dashboard → Feedback tab → Filter by Negative → Tap item → View Detail → Add tag → Reply

### Flow 3: Create & Share Survey
Survey tab → Create Survey → Add questions → Choose channels → Share link/QR

### Flow 4: Export Report
Analytics screen → Set date range → Export → Share CSV/PDF

### Flow 5: Browse Products & Leave Feedback
Catalog tab → Browse products → Product Detail → "Leave Feedback" → Fill Survey

---

## Typography
- **Headings**: font-bold, text-2xl / text-xl
- **Body**: font-normal, text-base / text-sm
- **Caption**: text-xs, text-muted
- **Numbers/Stats**: font-bold, text-3xl (for KPIs)

## Component Library
- `FeedbackCard` — แสดง feedback item ใน list
- `KPICard` — แสดง metric สำคัญ
- `SentimentBadge` — badge สี positive/neutral/negative
- `NPSScale` — 0-10 scale selector
- `StarRating` — 1-5 star selector
- `TagChip` — แท็กที่เพิ่ม/ลบได้
- `SurveyCard` — แสดง survey ใน list
- `ProductCard` — แสดงสินค้าใน grid
- `ContactItem` — แสดงช่องทางติดต่อ
