import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ── Reviews table ──────────────────────────────────────────
export const reviews = mysqlTable("reviews", {
  id: int("id").autoincrement().primaryKey(),
  /** Customer display name (not a logged-in user) */
  customerName: varchar("customerName", { length: 100 }).notNull(),
  /** Star rating 1-5 */
  rating: int("rating").notNull(),
  /** NPS score 0-10 (optional) */
  npsScore: int("npsScore"),
  /** Review comment text */
  comment: text("comment"),
  /** Product ID from local catalog (optional) */
  productId: varchar("productId", { length: 100 }),
  /** Product name snapshot */
  productName: varchar("productName", { length: 255 }),
  /** Purchase channel: LINE, website, walk-in */
  channel: varchar("channel", { length: 50 }),
  /** Computed sentiment: positive, neutral, negative */
  sentiment: varchar("sentiment", { length: 20 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;
