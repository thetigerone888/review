CREATE TABLE `reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerName` varchar(100) NOT NULL,
	`rating` int NOT NULL,
	`npsScore` int,
	`comment` text,
	`productId` varchar(100),
	`productName` varchar(255),
	`channel` varchar(50),
	`sentiment` varchar(20),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reviews_id` PRIMARY KEY(`id`)
);
